/**********************************************************************
 *
 * Filename:    crc.c
 * 
 * Description: Implementations of the CRC standards.
 *
 * Notes:       The parameters for each supported CRC standard are
 *				defined in the header file crc.h.  The implementations
 *				here should stand up to further additions to that list.
 *
 * Copyright (c) 2006 Anthony Massa and Michael Barr. All rights reserved.
 * This code is from the book Programming Embedded Systems, With C and
 * GNU Development Tools, 2nd Edition.
 * It is provided AS-IS, WITHOUT ANY WARRANTY either expressed or implied.
 * You may study, use, and modify it for any non-commercial purpose,
 * including teaching and use in open-source projects.
 * You may distribute it non-commercially as long as you retain this notice.
 * For a commercial use license, or to purchase the book,
 * please visit http://www.oreilly.com/catalog/embsys2.
 *
 **********************************************************************/

#include "stdint.h"
#include "crc.h"


/* Derive parameters from the standard-specific parameters in crc.h. */
#define WIDTH                       (8 * sizeof(crc_t))
#define TOPBIT                      (1 << (WIDTH - 1))


#if (REFLECT_DATA == TRUE)
    #undef  REFLECT_DATA
    #define REFLECT_DATA(X)			((uint8_t)reflect((X), 8))
#else
    #undef  REFLECT_DATA
    #define REFLECT_DATA(X)			(X)
#endif

#if (REFLECT_REMAINDER == TRUE)
    #undef  REFLECT_REMAINDER
    #define REFLECT_REMAINDER(X)	((crc_t)reflect((X), WIDTH))
#else
    #undef  REFLECT_REMAINDER
    #define REFLECT_REMAINDER(X)	(X)
#endif


crc_t crcTable[256];


/*********************************************************************
 *
 * Function:    reflect()
 * 
 * Description: Reorder the bits of a binary sequence, by reflecting
 *				them about the middle position.
 *
 * Notes:		No checking is done that nBits <= 32.
 *
 * Returns:		The reflection of the original data.
 *
 *********************************************************************/
static uint32_t reflect(uint32_t data, uint8_t nBits)
{
    uint32_t reflection = 0x00000000;
    int      bit;

	/* Reflect the data about the center bit. */
	for (bit = 0; bit < nBits; bit++)
	{
		/* If the LSB bit is set, set the reflection of it. */
		if (data & 0x01)
			reflection |= (1 << ((nBits - 1) - bit));

		data = (data >> 1);
	}

	return (reflection);
}


/*********************************************************************
 *
 * Function:    crcCompute
 * 
 * Description: Compute the CRC of a given message.
 *
 * Notes:	       
 *
 * Returns:     The CRC of the message.
 *
 *********************************************************************/
crc_t crcCompute(uint8_t const message[], uint32_t numBytes)
{
    crc_t    remainder = INITIAL_REMAINDER;
	uint32_t byte;
	int      nBit;

    /* Perform modulo-2 division, a byte at a time. */
    for (byte = 0; byte < numBytes; byte++)
    {
        /* Bring the next byte into the remainder. */
        remainder ^= (REFLECT_DATA(message[byte]) << (WIDTH - 8));

        /* Perform modulo-2 division, a bit at a time. */
        for (nBit = 8; nBit > 0; nBit--)
        {
            /* Try to divide the current data bit. */
            if (remainder & TOPBIT)
                remainder = (remainder << 1) ^ POLYNOMIAL;
            else
                remainder = (remainder << 1);
        }
    }

    /* The final remainder is the CRC result. */
    return (REFLECT_REMAINDER(remainder) ^ FINAL_XOR_VALUE);
}


/*********************************************************************
 *
 * Function:    crcInit()
 * 
 * Description: Populate the partial CRC lookup table.
 *
 * Notes:		This function must be rerun any time the CRC standard
 *				is changed.  If desired, it can be run "offline" and
 *				the table results stored in an embedded system's ROM.
 *
 * Returns:		None defined.
 *
 *********************************************************************/
void crcInit(void)
{
    crc_t remainder;
    int   dividend;
    int   bit;


    /* Compute the remainder of each possible dividend. */
    for (dividend = 0; dividend < 256; dividend++)
    {
        /* Start with the dividend followed by zeros. */
        remainder = dividend << (WIDTH - 8);

        /* Perform modulo-2 division, a bit at a time. */
        for (bit = 8; bit > 0; bit--)
        {
            /* Try to divide the current data bit. */			
            if (remainder & TOPBIT)
                remainder = (remainder << 1) ^ POLYNOMIAL;
            else
                remainder = (remainder << 1);
        }

        /* Store the result into the table. */
        crcTable[dividend] = remainder;
    }

}


/*********************************************************************
 *
 * Function:    crcFast
 * 
 * Description: Compute the CRC of a given message.
 *
 * Notes:		crcInit must be called first.
 *
 * Returns:		The CRC of the message.
 *
 *********************************************************************/
crc_t crcFast(uint8_t const message[], uint32_t nBytes)
{
    crc_t    remainder = INITIAL_REMAINDER;
    uint8_t  data;
	uint32_t byte;

    /* Divide the message by the polynomial, a byte at a time. */
    for (byte = 0; byte < nBytes; byte++)
    {
        data = REFLECT_DATA(message[byte]) ^ (remainder >> (WIDTH - 8));
  		remainder = crcTable[data] ^ (remainder << 8);
    }

    /* The final remainder is the CRC. */
    return (REFLECT_REMAINDER(remainder) ^ FINAL_XOR_VALUE);
}
