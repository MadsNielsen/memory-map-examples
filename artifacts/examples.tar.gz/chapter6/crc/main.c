/**********************************************************************
 *
 * Filename:    main.c
 * 
 * Description: A simple test program for the CRC implementations.
 *
 * Notes:       To test a different CRC standard, modify crc.h.
 *
 * Copyright (c) 2006 Anthony Massa and Michael Barr. All rights reserved.
 * This code is from the book Programming Embedded Systems, With C and
 * GNU Development Tools, 2nd Edition.
 * It is provided AS-IS, WITHOUT ANY WARRANTY either expressed or implied.
 * You may study, use, and modify it for any non-commercial purpose,
 * including teaching and use in open-source projects.
 * You may distribute it non-commercially as long as you retain this notice.
 * For a commercial use license, or to purchase the book,
 * please visit http://www.oreilly.com/catalog/embsys2.
 *
 **********************************************************************/

#include <stdio.h>
#include <string.h>
#include "stdint.h"
#include "crc.h"


/**********************************************************************
 *
 * Function:    main
 *
 * Description: Test program for CRC functions.
 * 
 * Notes:       
 *
 * Returns:     0 when done.
 *
 **********************************************************************/
int main(void)
{
    char test[] = "123456789";

    /* Print the check value for the selected CRC algorithm. */
    printf("The check value for the %s standard is 0x%X\n", CRC_NAME, CHECK_VALUE);

    /* Compute the CRC of the test message. */
    printf("The crcCompute() of \"123456789\" is 0x%X\n", crcCompute(test, strlen(test)));
    
    /* Compute the CRC of the test message, more efficiently. */
    crcInit();
    printf("The crcFast() of \"123456789\" is 0x%X\n", crcFast(test, strlen(test)));

    return 0;
}
