/**********************************************************************
 *
 * Filename:    main.c
 * 
 * Description: A simple test program for the memtest.
 *
 * Notes:       
 *
 * Copyright (c) 2006 Anthony Massa and Michael Barr. All rights reserved.
 * This code is from the book Programming Embedded Systems, With C and
 * GNU Development Tools, 2nd Edition.
 * It is provided AS-IS, WITHOUT ANY WARRANTY either expressed or implied.
 * You may study, use, and modify it for any non-commercial purpose,
 * including teaching and use in open-source projects.
 * You may distribute it non-commercially as long as you retain this notice.
 * For a commercial use license, or to purchase the book,
 * please visit http://www.oreilly.com/catalog/embsys2.
 *
 **********************************************************************/

#include <stdio.h>
#include <string.h>

#include "stdint.h"
#include "viperlite.h"
#include "memtest.h"
#include "led.h"


#define BASE_ADDRESS                (datum *)(0x00500000)
#define NUM_BYTES                   (0x10000)


/**********************************************************************
 *
 * Function:    main
 *
 * Description: Test a 64 KB block of DRAM.
 * 
 * Notes:       
 *
 * Returns:     0 on failure.
 *              1 on success.
 *
 **********************************************************************/
int main(void)
{
    datum *pFailAddr;

    /* Configure the LED control pins. */
    ledInit();

    /* Make sure all LEDs are off before we start the memory test. */
    ledOff(LED_GREEN | LED_YELLOW | LED_RED);

    if ((memtestDataBus(BASE_ADDRESS, &pFailAddr) != 1) ||
        (memtestAddressBus(BASE_ADDRESS, NUM_BYTES, &pFailAddr) != 1) ||
        (memtestDevice(BASE_ADDRESS, NUM_BYTES, &pFailAddr) != 1))
    {
        ledOn(LED_RED);
        return 0;
    }
    else
    {
        ledOn(LED_GREEN);
        return 1;
    }
}

