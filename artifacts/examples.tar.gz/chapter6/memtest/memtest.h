/**********************************************************************
 *
 * Filename:    memtest.h
 * 
 * Description: A header file for the memtest.
 *
 * Notes:       
 *
 * Copyright (c) 2006 Anthony Massa and Michael Barr. All rights reserved.
 * This code is from the book Programming Embedded Systems, With C and
 * GNU Development Tools, 2nd Edition.
 * It is provided AS-IS, WITHOUT ANY WARRANTY either expressed or implied.
 * You may study, use, and modify it for any non-commercial purpose,
 * including teaching and use in open-source projects.
 * You may distribute it non-commercially as long as you retain this notice.
 * For a commercial use license, or to purchase the book,
 * please visit http://www.oreilly.com/catalog/embsys2.
 *
 **********************************************************************/

#ifndef _MEMTEST_H
#define _MEMTEST_H


/* Set the data bus width to 32 bits. */
typedef uint32_t datum;


int memtestDataBus(datum * pAddress, datum **ppFailAddr);
int memtestAddressBus(datum *pBaseAddress, uint32_t numBytes, datum **ppFailAddr);
int memtestDevice(datum *pBaseAddress, uint32_t numBytes, datum **ppFailAddr);


#endif /* _MEMTEST_H */

