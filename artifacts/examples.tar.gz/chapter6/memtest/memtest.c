/**********************************************************************
 *
 * Filename:    memtest.c
 * 
 * Description: General-purpose memory testing functions.
 *
 * Notes:       This file is specific to the Arcom board.
 *
 *              This software can be easily ported to systems with
 *              different data bus widths by redefining 'datum'
 *              located in the header file memtest.h.
 *
 * 
 * Copyright (c) 2006 Anthony Massa and Michael Barr. All rights reserved.
 * This code is from the book Programming Embedded Systems, With C and
 * GNU Development Tools, 2nd Edition.
 * It is provided AS-IS, WITHOUT ANY WARRANTY either expressed or implied.
 * You may study, use, and modify it for any non-commercial purpose,
 * including teaching and use in open-source projects.
 * You may distribute it non-commercially as long as you retain this notice.
 * For a commercial use license, or to purchase the book,
 * please visit http://www.oreilly.com/catalog/embsys2.
 *
 **********************************************************************/

#include "stdint.h"
#include "viperlite.h"
#include "memtest.h"


/**********************************************************************
 *
 * Function:    memtestDataBus
 *
 * Description: Test the data bus wiring in a memory region by
 *              performing a walking 1's test at a fixed address
 *              within that region.  The address (and hence the
 *              memory region) is selected by the caller.
 *
 * Notes:       
 *
 * Returns:     0 if the test fails. The failure address is returned
 *              in the parameter ppFailAddr.
 *              1 if the test succeeds. The parameter ppFailAddr is
 *              set to NULL.
 *
 **********************************************************************/
int memtestDataBus(datum *pAddress, datum **ppFailAddr)
{
    datum pattern;

    *ppFailAddr = NULL;
     
    /* Perform a walking 1's test at the given address. */
    for (pattern = 1; pattern != 0; pattern <<= 1)
    {
        /* Write the test pattern. */
        *pAddress = pattern;
     
        /* Read it back (immediately is okay for this test). */
        if (*pAddress != pattern)
        {
            *ppFailAddr = pAddress; 
            return 0;
        }
    }
     
    return 1;
}


/********************************************************************** 
 * Function:    memtestAddressBus
 *
 * Description: Test the address bus wiring in a memory region by
 *              performing a walking 1's test on the relevant bits
 *              of the address and checking for aliasing.  The test
 *              will find single-bit address failures such as stuck 
 *              high, stuck low, and shorted pins.  The base address
 *              and size of the region are selected by the caller.
 *
 * Notes:       For best results, the selected base address should
 *              have enough LSB 0's to guarantee single address bit
 *              changes.  For example, to test a 64 KB region, select 
 *              a base address on a 64 KB boundary.  Also, the number
 *              of bytes must describe a power-of-two region size.
 *
 * Returns:     0 if the test fails. The failure address is returned
 *              in the parameter ppFailAddr.
 *              1 if the test succeeds. The parameter ppFailAddr is
 *              set to NULL.
 *
 **********************************************************************/
int memtestAddressBus(datum *pBaseAddress, uint32_t numBytes, datum **ppFailAddr)
{
    uint32_t addressMask = (numBytes - 1);
    uint32_t offset;
    uint32_t testOffset;    
    datum    pattern = (datum) 0xAAAAAAAA;
    datum    antipattern = (datum) ~pattern;

    *ppFailAddr = NULL;
     
    /* Write the default pattern at each of the power-of-two offsets. */
    for (offset = sizeof(datum); (offset & addressMask) != 0; offset <<= 1)
        pBaseAddress[offset] = pattern;
     
    /* Check for address bits stuck high. */
    pBaseAddress[0] = antipattern;
     
    for (offset = sizeof(datum); offset & addressMask; offset <<= 1)
    {
        if (pBaseAddress[offset] != pattern)
        {
            *ppFailAddr = &pBaseAddress[offset];
            return 0;
        }
    }
     
    pBaseAddress[0] = pattern;
     
    /* Check for address bits stuck low or shorted. */
    for (testOffset = sizeof(datum); testOffset & addressMask; testOffset <<= 1)
    {
        pBaseAddress[testOffset] = antipattern;
     
        for (offset = sizeof(datum); offset & addressMask; offset <<= 1)
        {
            if ((pBaseAddress[offset] != pattern) && (offset != testOffset))
            {
                *ppFailAddr = &pBaseAddress[offset];
                return 0;
            }
        }
     
        pBaseAddress[testOffset] = pattern;
    }
     
    return 1;
}


/**********************************************************************
 *
 * Function:    memtestDevice
 *
 * Description: Test the integrity of a physical memory device by
 *              performing an increment/decrement test over the
 *              entire region.  In the process, every storage bit 
 *              in the device is tested as a zero and a one.  The
 *              base address and the size of the region are
 *              selected by the caller.
 *
 * Notes:       
 *
 * Returns:     0 if the test fails. The failure address is returned
 *              in the parameter ppFailAddr.
 *              1 if the test succeeds. The parameter ppFailAddr is
 *              set to NULL.
 *
 **********************************************************************/
int memtestDevice(datum *pBaseAddress, uint32_t numBytes, datum **ppFailAddr)
{
    uint32_t offset;
    uint32_t numWords = numBytes / sizeof(datum);
    datum    pattern;

    *ppFailAddr = NULL;

    /* Fill memory with a known pattern. */
    for (pattern = 1, offset = 0; offset < numWords; pattern++, offset++)
        pBaseAddress[offset] = pattern;
     
    /* Check each location and invert it for the second pass. */
    for (pattern = 1, offset = 0; offset < numWords; pattern++, offset++)
    {
        if (pBaseAddress[offset] != pattern)
        {
            *ppFailAddr = &pBaseAddress[offset];
            return 0;
        }
     
        pBaseAddress[offset] = ~pattern;
    }
     
    /* Check each location for the inverted pattern and zero it. */
    for (pattern = 1, offset = 0; offset < numWords; pattern++, offset++)
    {
        if (pBaseAddress[offset] != ~pattern)
        {
            *ppFailAddr = &pBaseAddress[offset];
            return 0;
        }
     
        pBaseAddress[offset] = 0;
    }

    return 1;
}
