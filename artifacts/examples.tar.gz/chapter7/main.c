/**********************************************************************
 *
 * Filename:    main.c
 * 
 * Description: The main program file the serial driver example.
 *
 * Notes:       This file is specific to the Arcom board.
 * 
 * Copyright (c) 2006 Anthony Massa and Michael Barr. All rights reserved.
 * This code is from the book Programming Embedded Systems, With C and
 * GNU Development Tools, 2nd Edition.
 * It is provided AS-IS, WITHOUT ANY WARRANTY either expressed or implied.
 * You may study, use, and modify it for any non-commercial purpose,
 * including teaching and use in open-source projects.
 * You may distribute it non-commercially as long as you retain this notice.
 * For a commercial use license, or to purchase the book,
 * please visit http://www.oreilly.com/catalog/embsys2.
 *
 **********************************************************************/

#include "stdint.h"
#include "serial.h"


/**********************************************************************
 *
 * Function:    main
 *
 * Description: Exercise the serial device driver.
 * 
 * Notes:       
 *
 * Returns:     This routine contains an infinite loop, which can
 *              be exited by entering q.
 *
 **********************************************************************/
int main(void)
{
    char rcvChar = 0;

    /* Configure the UART for the serial driver. */
    serialInit();

    serialPutChar('s');
    serialPutChar('t');
    serialPutChar('a');
    serialPutChar('r');
    serialPutChar('t');
    serialPutChar('\r');
    serialPutChar('\n');

    while (rcvChar != 'q')
    {
        /* Wait for an incoming character. */
        rcvChar = serialGetChar();

        /* Echo the character back along with a carriage return and line feed. */
        serialPutChar(rcvChar);
        serialPutChar('\r');
        serialPutChar('\n');
    }

    return 0;
}

