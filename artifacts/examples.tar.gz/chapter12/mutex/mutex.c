/**********************************************************************
 *
 * Filename:    mutex.c
 * 
 * Description: Linux mutex program.
 *
 * Notes:       
 *
 * Copyright (c) 2006 Anthony Massa and Michael Barr. All rights reserved.
 * This code is from the book Programming Embedded Systems, With C and
 * GNU Development Tools, 2nd Edition.
 * It is provided AS-IS, WITHOUT ANY WARRANTY either expressed or implied.
 * You may study, use, and modify it for any non-commercial purpose,
 * including teaching and use in open-source projects.
 * You may distribute it non-commercially as long as you retain this notice.
 * For a commercial use license, or to purchase the book,
 * please visit http://www.oreilly.com/catalog/embsys2.
 *
 **********************************************************************/

#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
#include "libdevmem.h"
#include "stdint.h"
#include "pxa255.h"


/* Declare the task variables. */
pthread_t incrementTaskObj;
pthread_t decrementTaskObj;

pthread_mutex_t sharedVariableMutex;
int32_t gSharedVariable = 0;


/**********************************************************************
 *
 * Function:    incrementTask
 *
 * Description: This task increments a shared variable.
 *
 * Notes:       
 *
 * Returns:     None.
 *
 **********************************************************************/
void incrementTask(void *param)
{
    while (1)
    {
        /* Delay for 3 seconds. */
        sleep(3);

        /* Wait for the mutex before accessing the GPIO registers. */
        pthread_mutex_lock(&sharedVariableMutex);

        gSharedVariable++;

        printf("Increment Task: shared variable value is %d\n",
               gSharedVariable);

        /* Release the mutex for other task to use. */
        pthread_mutex_unlock(&sharedVariableMutex);
    }
}


/**********************************************************************
 *
 * Function:    decrementTask
 *
 * Description: This task decrements a shared variable.
 *
 * Notes:       
 *
 * Returns:     None.
 *
 **********************************************************************/ 
void decrementTask(void *param)
{
    while (1)
    {
        /* Delay for 7 seconds. */
        sleep(7);

        /* Wait for the mutex to become available. */
        pthread_mutex_lock(&sharedVariableMutex);

        gSharedVariable--;

        printf("Decrement Task: shared variable value is %d\n",
               gSharedVariable);

        /* Release the mutex. */
        pthread_mutex_unlock(&sharedVariableMutex);
    }
}


/**********************************************************************
 *
 * Function:    main
 *
 * Description: Main routine for the Linux mutex example. This
 *              function creates the mutex and then the increment and
 *              decrement tasks.
 * 
 * Notes:       
 *
 * Returns:     0. 
 *
 **********************************************************************/
int main(void)
{
    /* Create the mutex for accessing the shared variable using the
     * default attributes. */
    pthread_mutex_init(&sharedVariableMutex, NULL);

    /* Create the increment and decrement tasks using the default task
     * attributes. Do not pass in any parameters to the tasks. */
    pthread_create(&incrementTaskObj, NULL, (void *)incrementTask, NULL);
    pthread_create(&decrementTaskObj, NULL, (void *)decrementTask, NULL);

    /* Allow the tasks to run. */
    pthread_join(incrementTaskObj, NULL);
    pthread_join(decrementTaskObj, NULL);

    return 0;
}

