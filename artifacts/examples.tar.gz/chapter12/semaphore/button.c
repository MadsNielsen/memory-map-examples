/**********************************************************************
 *
 * Filename:    button.c
 * 
 * Description: Button device driver.
 *
 * Notes:       This file is specific to the Arcom board.
 * 
 * Copyright (c) 2006 Anthony Massa and Michael Barr. All rights reserved.
 * This code is from the book Programming Embedded Systems, With C and
 * GNU Development Tools, 2nd Edition.
 * It is provided AS-IS, WITHOUT ANY WARRANTY either expressed or implied.
 * You may study, use, and modify it for any non-commercial purpose,
 * including teaching and use in open-source projects.
 * You may distribute it non-commercially as long as you retain this notice.
 * For a commercial use license, or to purchase the book,
 * please visit http://www.oreilly.com/catalog/embsys2.
 *
 **********************************************************************/

#include "stdint.h"
#include "pxa255.h"
#include "viperlite.h"
#include "button.h"


extern uint8_t *gButtonRegister;


/**********************************************************************
 *
 * Function:    buttonDebounce
 *
 * Description: This function gets the current state of the button.
 *
 * Notes:       This function is specific to the Arcom board. The
 *              default state on the button input signals is high.
 *              When a button is pressed, the input signal goes low.
 *
 * Returns:     The current state of the SW0 button.
 *
 **********************************************************************/ 
uint8_t buttonRead(void)
{
    return (~(*gButtonRegister) & 0x01);
}


/**********************************************************************
 *
 * Function:    buttonDebounce
 *
 * Description: This function debounces buttons.
 *
 * Notes:       
 *
 * Returns:     TRUE if the button edge is detected, otherwise
 *              FALSE is returned.
 *
 **********************************************************************/ 
uint8_t buttonDebounce(void)
{
    static uint16_t buttonState = 0;
    uint8_t pinState;    

    pinState = buttonRead();

    /* Store the current debounce status. */
    buttonState = ((buttonState << 1) | pinState | 0xE000);

    if (buttonState == 0xF000)
        return TRUE;

    return FALSE;
}
