/**********************************************************************
 *
 * Filename:    semaphore.c
 * 
 * Description: Linux semaphore program.
 *
 * Notes:       
 *
 * Copyright (c) 2006 Anthony Massa and Michael Barr. All rights reserved.
 * This code is from the book Programming Embedded Systems, With C and
 * GNU Development Tools, 2nd Edition.
 * It is provided AS-IS, WITHOUT ANY WARRANTY either expressed or implied.
 * You may study, use, and modify it for any non-commercial purpose,
 * including teaching and use in open-source projects.
 * You may distribute it non-commercially as long as you retain this notice.
 * For a commercial use license, or to purchase the book,
 * please visit http://www.oreilly.com/catalog/embsys2.
 *
 **********************************************************************/

#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>
#include <sys/mman.h>
#include <fcntl.h>
#include "stdint.h"
#include "pxa255.h"
#include "viperlite.h"
#include "button.h"
#include "led.h"


#define GPIO_REGISTERS_BASE_ADDR        (0x40E00000)
#define BUTTON_REGISTER_BASE_ADDR       (0x14500000)


uint32_t *gGpioRegisters;
uint8_t *gButtonRegister;

/* Declare the task variables. */
pthread_t consumerTaskObj;
pthread_t producerTaskObj;

sem_t semButton;


/**********************************************************************
 *
 * Function:    producerTask
 *
 * Description: This task monitors button SW0. Once pressed, the button
 *              is debounced and the semaphore is signaled waking the
 *              waiting consumer task.
 *
 * Notes:        
 *
 * Returns:     None.
 *
 **********************************************************************/ 
void producerTask(void *param)
{
    int buttonOn;

    while (1)
    {
        /* Delay for 10 milliseconds. */
        usleep(10000);

        /* Check whether the SW0 button has been pressed. */
        buttonOn = buttonDebounce();

        /* If button SW0 was pressed, signal the consumer task. */
        if (buttonOn)
            sem_post(&semButton);
    }
}


/**********************************************************************
 *
 * Function:    consumerTask
 *
 * Description: This task waits for the semaphore signal from the
 *              producer task. Once the signal is received, the task
 *              outputs a message and toggles the green LED.
 *
 * Notes:       
 *
 * Returns:     None.
 *
 **********************************************************************/ 
void consumerTask(void *param)
{
    while (1)
    {
        /* Wait for the signal. */
        sem_wait(&semButton);

        printf("Button SW0 was pressed.\n");

        ledToggle();
    }
}


/**********************************************************************
 *
 * Function:    blinkMapHardwareRegisters
 *
 * Description: This function maps the processor's GPIO registers and
 *              the button control register so they can be accessed in
 *              user space. The resulting mapped memory is stored in a
 *              global variable for access by the drivers.
 *
 * Notes:       This function is specific to embedded Linux.
 *
 * Returns:     None.
 *
 **********************************************************************/ 
void blinkMapHardwareRegisters(void)
{
    int fd = 0;

    if ((fd = open("/dev/mem", O_RDWR | O_SYNC)) < 0)
        printf("Cannot open device file.\n");

    if (MAP_FAILED == (gGpioRegisters = mmap(NULL, 4096, PROT_READ | PROT_WRITE, MAP_SHARED, fd, GPIO_REGISTERS_BASE_ADDR)))
        printf("Cannot map device file for GPIO registers.\n");

    if (MAP_FAILED == (gButtonRegister = mmap(NULL, 4096, PROT_READ | PROT_WRITE, MAP_SHARED, fd, BUTTON_REGISTER_BASE_ADDR)))
        printf("Cannot map device file for button register.\n");
}


/**********************************************************************
 *
 * Function:    main
 *
 * Description: Main routine for the Linux semaphore example. This
 *              function creates the semaphore and then the increment
 *              and decrement tasks.
 * 
 * Notes:       
 *
 * Returns:     0.
 *
 **********************************************************************/
int main(void)
{
    /* Map the hardware registers into user space. */
    blinkMapHardwareRegisters();

    /* Configure the green LED control pin. */
    ledInit();

    /* Create the semaphore for this process only and with an initial
     * value of zero. */
    sem_init(&semButton, 0, 0);

    /* Create the producer and consumer tasks using the default task
     * attributes. Do not pass in any parameters to the tasks. */
    pthread_create(&producerTaskObj, NULL, (void *)producerTask, NULL);
    pthread_create(&consumerTaskObj, NULL, (void *)consumerTask, NULL);

    printf("Linux semaphore example - press button SW0.\n");

    /* Allow the tasks to run. */
    pthread_join(producerTaskObj, NULL);
    pthread_join(consumerTaskObj, NULL);

    return 0;
}

