/**********************************************************************
 *
 * Filename:    blink.c
 * 
 * Description: Linux Blinking LED program.
 *
 * Notes:       
 *
 * Copyright (c) 2006 Anthony Massa and Michael Barr. All rights reserved.
 * This code is from the book Programming Embedded Systems, With C and
 * GNU Development Tools, 2nd Edition.
 * It is provided AS-IS, WITHOUT ANY WARRANTY either expressed or implied.
 * You may study, use, and modify it for any non-commercial purpose,
 * including teaching and use in open-source projects.
 * You may distribute it non-commercially as long as you retain this notice.
 * For a commercial use license, or to purchase the book,
 * please visit http://www.oreilly.com/catalog/embsys2.
 *
 **********************************************************************/

#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
#include <sys/mman.h>
#include <fcntl.h>
#include "stdint.h"
#include "pxa255.h"
#include "led.h"


#define GPIO_REGISTERS_BASE_ADDR       (0x40E00000)


uint32_t *gGpioRegisters;

/* Declare the task variables. */
pthread_t ledTaskObj;


/**********************************************************************
 *
 * Function:    blinkLedTask
 *
 * Description: This task handles toggling the green LED at a
 *              constant interval.
 *
 * Notes:       
 *
 * Returns:     None.
 *
 **********************************************************************/ 
void blinkLedTask(void *param)
{
    while (1)
    {
        /* Delay for 500 milliseconds. */
        usleep(500000);

        ledToggle();
    }
}


/**********************************************************************
 *
 * Function:    blinkMapHardwareRegisters
 *
 * Description: This function maps the processor's GPIO registers so
 *              they can be accessed in user space. The resulting
 *              mapped memory is stored in a global variable for
 *              access by the drivers.
 *
 * Notes:       This function is specific to embedded Linux.
 *
 * Returns:     None.
 *
 **********************************************************************/ 
void blinkMapHardwareRegisters(void)
{
    int fd = 0;

    if ((fd = open("/dev/mem", O_RDWR | O_SYNC)) < 0)
    {
        printf("Cannot open device file.\n");
    }

    if (MAP_FAILED == (gGpioRegisters = mmap(NULL, 4096, PROT_READ | PROT_WRITE, MAP_SHARED, fd, GPIO_REGISTERS_BASE_ADDR)))
    {
        printf("Cannot map device file.\n");
    }
}


/**********************************************************************
 *
 * Function:    main
 *
 * Description: Main routine for Linux Blinking LED program. This
 *              function creates the LED task.
 * 
 * Notes:       
 *
 * Returns:    0.
 *
 **********************************************************************/
int main(void)
{
    /* Map the hardware registers into user space. */
    blinkMapHardwareRegisters();

    /* Configure the green LED control pin. */
    ledInit();

    /* Create the LED task using the default task attributes. Do not
     * pass in any parameters to the task. */
    pthread_create(&ledTaskObj, NULL, (void *)blinkLedTask, NULL);

    /* Allow the LED task to run. */
    pthread_join(ledTaskObj, NULL);

    return 0;
}


