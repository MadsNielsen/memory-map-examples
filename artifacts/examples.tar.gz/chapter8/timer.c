/**********************************************************************
 *
 * Filename:    timer.c
 * 
 * Description: Timer device driver.
 *
 * Notes:       This file is specific to the Arcom board.
 * 
 * Copyright (c) 2006 Anthony Massa and Michael Barr. All rights reserved.
 * This code is from the book Programming Embedded Systems, With C and
 * GNU Development Tools, 2nd Edition.
 * It is provided AS-IS, WITHOUT ANY WARRANTY either expressed or implied.
 * You may study, use, and modify it for any non-commercial purpose,
 * including teaching and use in open-source projects.
 * You may distribute it non-commercially as long as you retain this notice.
 * For a commercial use license, or to purchase the book,
 * please visit http://www.oreilly.com/catalog/embsys2.
 *
 **********************************************************************/

#include "stdint.h"
#include "pxa255.h"
#include "viperlite.h"
#include "led.h"
#include "timer.h"


#define TIMER_INTERVAL_500MS        (0x001C2000)


/**********************************************************************
 *
 * Function:    timerInit
 *
 * Description: Initialize and start the timer.
 * 
 * Notes:       This function is specific to the Arcom board.
 *              Ensure an ISR has been installed for the timer prior
 *              to calling this routine.
 *
 * Returns:     None.
 *
 **********************************************************************/
void timerInit(void)
{
    static int bInitialized = FALSE;

    /* Initialize the timer only once. */
    if (bInitialized == FALSE)
    {
        /* Acknowledge any outstanding timer interrupts. */
        TIMER_STATUS_REG = TIMER_0_MATCH;

        /* Initialize the timer interval. */
        TIMER_0_MATCH_REG = (TIMER_COUNT_REG + TIMER_INTERVAL_500MS);

        /* Enable the timer interrupt in the timer peripheral. */
        TIMER_INT_ENABLE_REG |= TIMER_0_INTEN;

        /* Enable the timer interrupt in the interrupt controller. */
        INTERRUPT_ENABLE_REG |= TIMER_0_ENABLE;

        bInitialized = TRUE;
    }
}


/**********************************************************************
 *
 * Function:    timerInterrupt
 *
 * Description: Timer 0 interrupt service routine.
 * 
 * Notes:       This function is specific to the Arcom board.
 *
 * Returns:     None.
 *
 **********************************************************************/
void timerInterrupt(void)
{
    /* Acknowledge the timer 0 interrupt. */
    TIMER_STATUS_REG = TIMER_0_MATCH;

    /* Change the state of the green LED. */
    ledToggle();

    /* Set the new timer interval. */
    TIMER_0_MATCH_REG = (TIMER_COUNT_REG + TIMER_INTERVAL_500MS);
}

