/**********************************************************************
 *
 * Filename:    blink.c
 * 
 * Description: The Improved Blinking LED program.
 *
 * Notes:       This file is specific to the Arcom board.
 * 
 * Copyright (c) 2006 Anthony Massa and Michael Barr. All rights reserved.
 * This code is from the book Programming Embedded Systems, With C and
 * GNU Development Tools, 2nd Edition.
 * It is provided AS-IS, WITHOUT ANY WARRANTY either expressed or implied.
 * You may study, use, and modify it for any non-commercial purpose,
 * including teaching and use in open-source projects.
 * You may distribute it non-commercially as long as you retain this notice.
 * For a commercial use license, or to purchase the book,
 * please visit http://www.oreilly.com/catalog/embsys2.
 *
 **********************************************************************/

#include "stdint.h"
#include "pxa255.h"
#include "viperlite.h"
#include "led.h"
#include "timer.h"


/**********************************************************************
 *
 * Function:    interruptInit
 *
 * Description: This function remaps the ARM processor's IRQ interrupt
 *              vector to the specified ISR.
 *
 * Notes:       This function is specific to the Arcom board. RedBoot
 *              initially maps all interrupt vectors to its own
 *              handlers. This function overwrites the IRQ interrupt
 *              vector in the vector table so that the new ISR is
 *              called for IRQ interrupts.
 *
 * Returns:     None.
 *
 **********************************************************************/
void interruptInit(uint32_t irq_handler)
{
    volatile uint32_t *irq_vector;

    /* Set the pointer to the address (0x38) of the IRQ interrupt in the
     * interrupt vector table. */
    irq_vector = (uint32_t *)(0x00000038);

    /* Install the new IRQ interrupt service routine. */
    *irq_vector = irq_handler;

    /* Enable IRQ interrupts. */
    asm(
        "mrs r8,cpsr        \n\t"
        "bic r8,r8,#0x80    \n\t"
        "msr cpsr,r8        \n\t"
       );
}


/**********************************************************************
 *
 * Function:    main
 *
 * Description: Blink the green LED once a second.
 * 
 * Notes:       
 *
 * Returns:     This routine contains an infinite loop.
 *
 **********************************************************************/
int main(void)
{
    /* Ensure the data and instruction caches are enabled. */
    DCACHE_ENABLE();
    ICACHE_ENABLE();

    /* Install timer interrupt handler. This routine is specific
     * to the Arcom board and the RedBoot ROM monitor. */
    interruptInit((uint32_t)&timerInterrupt);

    /* Configure the green LED control pin. */
    ledInit();

    /* Configure and start the timer. */
    timerInit();

    while (1)
        ;

    return 0;
}

