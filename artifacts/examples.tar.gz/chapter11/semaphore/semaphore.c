/**********************************************************************
 *
 * Filename:    semaphore.c
 * 
 * Description: eCos semaphore program.
 *
 * Notes:       
 *
 * Copyright (c) 2006 Anthony Massa and Michael Barr. All rights reserved.
 * This code is from the book Programming Embedded Systems, With C and
 * GNU Development Tools, 2nd Edition.
 * It is provided AS-IS, WITHOUT ANY WARRANTY either expressed or implied.
 * You may study, use, and modify it for any non-commercial purpose,
 * including teaching and use in open-source projects.
 * You may distribute it non-commercially as long as you retain this notice.
 * For a commercial use license, or to purchase the book,
 * please visit http://www.oreilly.com/catalog/embsys2.
 *
 **********************************************************************/

#include <cyg/kernel/kapi.h>
#include <cyg/infra/diag.h>
#include "stdint.h"
#include "pxa255.h"
#include "viperlite.h"
#include "button.h"
#include "led.h"


#define TICKS_PER_SECOND	        (100)

#define PRODUCER_TASK_STACK_SIZE    (4096)
#define PRODUCER_TASK_PRIORITY	    (12)

#define CONSUMER_TASK_STACK_SIZE    (4096)
#define CONSUMER_TASK_PRIORITY	    (12)


/* Declare the task variables. */
int8_t producerTaskStack[PRODUCER_TASK_STACK_SIZE];
cyg_thread producerTaskObj;
cyg_handle_t producerTaskHdl;

int8_t consumerTaskStack[CONSUMER_TASK_STACK_SIZE];
cyg_thread consumerTaskObj;
cyg_handle_t consumerTaskHdl;

cyg_sem_t semButton;


/**********************************************************************
 *
 * Function:    producerTask
 *
 * Description: This task monitors button SW0. Once pressed, the button
 *              is debounced and the semaphore is signaled waking the
 *              waiting consumer task.
 *
 * Notes:        
 *
 * Returns:     None.
 *
 **********************************************************************/ 
void producerTask(cyg_addrword_t data)
{
    int buttonOn;

    while (1)
    {
        /* Delay for 10 milliseconds. */
        cyg_thread_delay(TICKS_PER_SECOND / 100);

        /* Check whether the SW0 button has been pressed. */
        buttonOn = buttonDebounce();

        /* If button SW0 was pressed, signal the consumer task. */
        if (buttonOn)
            cyg_semaphore_post(&semButton);
    }
}


/**********************************************************************
 *
 * Function:    consumerTask
 *
 * Description: This task waits for the semaphore signal from the
 *              producer task. Once the signal is received, the task
 *              outputs a message.
 *
 * Notes:       
 *
 * Returns:     None.
 *
 **********************************************************************/ 
void consumerTask(cyg_addrword_t data)
{
    while (1)
    {
        /* Wait for the signal. */
        cyg_semaphore_wait(&semButton);

        diag_printf("Button SW0 was pressed.\n");

        ledToggle();
    }
}


/**********************************************************************
 *
 * Function:    cyg_user_start
 *
 * Description: Main routine for the eCos semaphore program. This
 *              function creates the semaphore and the producer and
 *              consumer tasks.
 * 
 * Notes:       This routine invokes the scheduler upon exit.
 *
 * Returns:     None.
 *
 **********************************************************************/
void cyg_user_start(void)
{
    /* Configure the green LED control pin. */
    ledInit();

    /* Create the semaphore with an initial value of zero. */
    cyg_semaphore_init(&semButton, 0);

    /* Create the producer and consumer tasks. */
    cyg_thread_create(PRODUCER_TASK_PRIORITY,
                      producerTask,
                      (cyg_addrword_t)0,
                      "Producer Task",
                      (void *)producerTaskStack,
                      PRODUCER_TASK_STACK_SIZE,
                      &producerTaskHdl,
                      &producerTaskObj);

    cyg_thread_create(CONSUMER_TASK_PRIORITY,
                      consumerTask,
                      (cyg_addrword_t)0,
                      "Consumer Task",
                      (void *)consumerTaskStack,
                      CONSUMER_TASK_STACK_SIZE,
                      &consumerTaskHdl,
                      &consumerTaskObj);

    /* Notify the scheduler to start running the tasks. */
    cyg_thread_resume(producerTaskHdl);
    cyg_thread_resume(consumerTaskHdl);

    diag_printf("eCos semaphore example - press button SW0.\n");
}

