/**********************************************************************
 *
 * Filename:    mutex.c
 * 
 * Description: eCos mutex program.
 *
 * Notes:       
 *
 * Copyright (c) 2006 Anthony Massa and Michael Barr. All rights reserved.
 * This code is from the book Programming Embedded Systems, With C and
 * GNU Development Tools, 2nd Edition.
 * It is provided AS-IS, WITHOUT ANY WARRANTY either expressed or implied.
 * You may study, use, and modify it for any non-commercial purpose,
 * including teaching and use in open-source projects.
 * You may distribute it non-commercially as long as you retain this notice.
 * For a commercial use license, or to purchase the book,
 * please visit http://www.oreilly.com/catalog/embsys2.
 *
 **********************************************************************/

#include <cyg/kernel/kapi.h>
#include <cyg/infra/diag.h>
#include "stdint.h"
#include "pxa255.h"


#define INCREMENT_TASK_STACK_SIZE   (4096)
#define INCREMENT_TASK_PRIORITY	    (12)

#define DECREMENT_TASK_STACK_SIZE   (4096)
#define DECREMENT_TASK_PRIORITY	    (12)

#define TICKS_PER_SECOND	        (100)


/* Declare the task variables. */
int8_t incrementTaskStack[INCREMENT_TASK_STACK_SIZE];
cyg_thread incrementTaskObj;
cyg_handle_t incrementTaskHdl;

int8_t decrementTaskStack[INCREMENT_TASK_STACK_SIZE];
cyg_thread decrementTaskObj;
cyg_handle_t decrementTaskHdl;

cyg_mutex_t sharedVariableMutex;
int32_t gSharedVariable = 0;


/**********************************************************************
 *
 * Function:    incrementTask
 *
 * Description: This task increments a shared variable.
 *
 * Notes:       
 *
 * Returns:     None.
 *
 **********************************************************************/ 
void incrementTask(cyg_addrword_t data)
{
    while (1)
    {
        /* Delay for 3 seconds. */
        cyg_thread_delay(TICKS_PER_SECOND * 3);

        /* Wait for the mutex to become available. */
        cyg_mutex_lock(&sharedVariableMutex);

        gSharedVariable++;

        diag_printf("Increment Task: shared variable value is %d\n",
                    gSharedVariable);

        /* Release the mutex. */
        cyg_mutex_unlock(&sharedVariableMutex);
    }
}


/**********************************************************************
 *
 * Function:    decrementTask
 *
 * Description: This task decrements a shared variable.
 *
 * Notes:       
 *
 * Returns:     None.
 *
 **********************************************************************/ 
void decrementTask(cyg_addrword_t data)
{
    while (1)
    {
        /* Delay for 7 seconds. */
        cyg_thread_delay(TICKS_PER_SECOND * 7);

        /* Wait for the mutex to become available. */
        cyg_mutex_lock(&sharedVariableMutex);

        gSharedVariable--;

        diag_printf("Decrement Task: shared variable value is %d\n",
                    gSharedVariable);

        /* Release the mutex. */
        cyg_mutex_unlock(&sharedVariableMutex);
    }
}


/**********************************************************************
 *
 * Function:    cyg_user_start
 *
 * Description: Main routine for the eCos mutex example. This function
 *              creates the mutex and then the increment and decrement
 *              tasks.
 * 
 * Notes:       This routine invokes the scheduler upon exit.
 *
 * Returns:     None.
 *
 **********************************************************************/
void cyg_user_start(void)
{
    /* Create the mutex for accessing the shared variable. */
    cyg_mutex_init(&sharedVariableMutex);

    /* Create the increment and decrement tasks. */
    cyg_thread_create(INCREMENT_TASK_PRIORITY,
                      incrementTask,
                      (cyg_addrword_t)0,
                      "Increment Task",
                      (void *)incrementTaskStack,
                      INCREMENT_TASK_STACK_SIZE,
                      &incrementTaskHdl,
                      &incrementTaskObj);

    cyg_thread_create(DECREMENT_TASK_PRIORITY,
                      decrementTask,
                      (cyg_addrword_t)0,
                      "Decrement Task",
                      (void *)decrementTaskStack,
                      DECREMENT_TASK_STACK_SIZE,
                      &decrementTaskHdl,
                      &decrementTaskObj);

    /* Notify the scheduler to start running the tasks. */
    cyg_thread_resume(incrementTaskHdl);
    cyg_thread_resume(decrementTaskHdl);

    diag_printf("eCos mutex example.\n");
}


