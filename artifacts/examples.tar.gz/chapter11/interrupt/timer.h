/**********************************************************************
 *
 * Filename:    timer.h
 * 
 * Description: Header file for timer device driver.
 *
 * Notes:       
 * 
 * Copyright (c) 2006 Anthony Massa and Michael Barr. All rights reserved.
 * This code is from the book Programming Embedded Systems, With C and
 * GNU Development Tools, 2nd Edition.
 * It is provided AS-IS, WITHOUT ANY WARRANTY either expressed or implied.
 * You may study, use, and modify it for any non-commercial purpose,
 * including teaching and use in open-source projects.
 * You may distribute it non-commercially as long as you retain this notice.
 * For a commercial use license, or to purchase the book,
 * please visit http://www.oreilly.com/catalog/embsys2.
 *
 **********************************************************************/

#ifndef _TIMER_H
#define _TIMER_H


extern cyg_handle_t timerInterruptHdl;
extern cyg_interrupt timerInterruptObj;
extern cyg_vector_t timerInterruptVector;

extern cyg_sem_t ledToggleSemaphore;


void timerInit(void);
uint32_t timerIsr(cyg_vector_t vector, cyg_addrword_t data);
void timerDsr(cyg_vector_t vector, cyg_ucount32 count, cyg_addrword_t data);


#endif /* _TIMER_H */
