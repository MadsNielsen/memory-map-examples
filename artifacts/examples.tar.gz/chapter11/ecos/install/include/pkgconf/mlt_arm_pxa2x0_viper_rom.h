#ifndef __ASSEMBLER__
#include <cyg/infra/cyg_type.h>
#include <stddef.h>
#endif

#define CYGMEM_REGION_ram			(0x00000000)
#define CYGMEM_REGION_ram_SIZE			(0x04000000)
#define CYGMEM_REGION_ram_ATTR			(CYGMEM_REGION_ATTR_R | CYGMEM_REGION_ATTR_W)
#define CYGMEM_REGION_rom			(0x50000000)
#define CYGMEM_REGION_rom_SIZE			(0x00100000)
#define CYGMEM_REGION_rom_ATTR			(CYGMEM_REGION_ATTR_R)
#ifndef __ASSEMBLER__
extern char CYG_LABEL_NAME			(__heap1) [];
#endif

#ifdef CYGPKG_REDBOOT
#  ifndef __ASSEMBLER__
    extern char CYG_LABEL_NAME 			(__workspace) [];
#  endif
#  define CYGMEM_SECTION_heap1                    (CYG_LABEL_NAME (__heap1))
#  define CYGMEM_SECTION_heap1_SIZE               ((size_t) CYG_LABEL_NAME (__workspace) - (size_t) CYG_LABEL_NAME (__heap1))

#  define CYGMEM_SECTION_workspace                (CYG_LABEL_NAME (__workspace))
#  define CYGMEM_SECTION_workspace_SIZE           ((size_t)CYGMEM_REGION_ram_SIZE - (size_t) CYG_LABEL_NAME (__workspace))
#else
#  define CYGMEM_SECTION_heap1                    (CYG_LABEL_NAME (__heap1))
#  define CYGMEM_SECTION_heap1_SIZE               ((size_t)CYGMEM_REGION_ram_SIZE - (size_t) CYG_LABEL_NAME (__heap1))
#endif
