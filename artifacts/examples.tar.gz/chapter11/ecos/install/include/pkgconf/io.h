#ifndef CYGONCE_PKGCONF_IO_H
#define CYGONCE_PKGCONF_IO_H
/*
 * File <pkgconf/io.h>
 *
 * This file is generated automatically by the configuration
 * system. It should not be edited. Any changes to this file
 * may be overwritten.
 */

#define CYGPKG_IO_FILE_SUPPORT 1
#define CYGPKG_IO_NFILE 16
#define CYGPKG_IO_NFILE_16

#endif
