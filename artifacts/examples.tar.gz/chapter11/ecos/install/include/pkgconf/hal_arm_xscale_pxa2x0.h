#ifndef CYGONCE_PKGCONF_HAL_ARM_XSCALE_PXA2X0_H
#define CYGONCE_PKGCONF_HAL_ARM_XSCALE_PXA2X0_H
/*
 * File <pkgconf/hal_arm_xscale_pxa2x0.h>
 *
 * This file is generated automatically by the configuration
 * system. It should not be edited. Any changes to this file
 * may be overwritten.
 */

#define CYGBLD_HAL_VAR_INTS_H <cyg/hal/hal_var_ints.h>
#define CYGBLD_HAL_VAR_H <cyg/hal/hal_pxa2x0.h>
#define CYGOPT_HAL_ARM_XSCALE_PXA2X0_VARIANT PXA25X
#define CYGOPT_HAL_ARM_XSCALE_PXA2X0_VARIANT_PXA25X
#define CYGNUM_HAL_RTC_NUMERATOR 1000000000
#define CYGNUM_HAL_RTC_NUMERATOR_1000000000
#define CYGNUM_HAL_RTC_DENOMINATOR 100
#define CYGNUM_HAL_RTC_DENOMINATOR_100
#define CYGNUM_HAL_RTC_PERIOD 36864
#define CYGNUM_HAL_RTC_PERIOD_36864
#define CYGHWR_HAL_ARM_PXA2X0_FFUART 1
#define CYGHWR_HAL_ARM_PXA2X0_FFUART_1
#define CYGHWR_HAL_ARM_PXA2X0_BTUART 1
#define CYGHWR_HAL_ARM_PXA2X0_BTUART_1
#define CYGHWR_HAL_ARM_PXA2X0_STUART 1
#define CYGHWR_HAL_ARM_PXA2X0_STUART_1
#define CYGBLD_BUILD_HAL_ARM_XSCALE_PXA2X0_SERIAL_DIAG 1

#endif
