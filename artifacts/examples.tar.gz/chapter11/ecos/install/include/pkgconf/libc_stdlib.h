#ifndef CYGONCE_PKGCONF_LIBC_STDLIB_H
#define CYGONCE_PKGCONF_LIBC_STDLIB_H
/*
 * File <pkgconf/libc_stdlib.h>
 *
 * This file is generated automatically by the configuration
 * system. It should not be edited. Any changes to this file
 * may be overwritten.
 */

#define CYGPKG_LIBC_RAND 1
#define CYGNUM_LIBC_RAND_SEED 1
#define CYGNUM_LIBC_RAND_SEED_1
#define CYGNUM_LIBC_RAND_TRACE_LEVEL 0
#define CYGNUM_LIBC_RAND_TRACE_LEVEL_0
#define CYGIMP_LIBC_RAND_SIMPLE1 1
#define CYGFUN_LIBC_strtod 1
#define CYGFUN_LIBC_STDLIB_CONV_LONGLONG 1
#define CYGNUM_LIBC_BSEARCH_TRACE_LEVEL 0
#define CYGNUM_LIBC_BSEARCH_TRACE_LEVEL_0
#define CYGNUM_LIBC_QSORT_TRACE_LEVEL 0
#define CYGNUM_LIBC_QSORT_TRACE_LEVEL_0

#endif
