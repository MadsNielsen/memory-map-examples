#ifndef CYGONCE_PKGCONF_HEAPS_HXX
#define CYGONCE_PKGCONF_HEAPS_HXX
/* <pkgconf/heaps.hxx> */

/* This is a generated file - do not edit! */

#define CYGMEM_HEAP_COUNT 1
#include <cyg/memalloc/dlmalloc.hxx>

extern Cyg_Mempool_dlmalloc *cygmem_memalloc_heaps[ 2 ];

#endif
/* EOF <pkgconf/heaps.hxx> */
