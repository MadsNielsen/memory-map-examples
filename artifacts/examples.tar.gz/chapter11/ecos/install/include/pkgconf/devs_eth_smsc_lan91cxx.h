#ifndef CYGONCE_PKGCONF_DEVS_ETH_SMSC_LAN91CXX_H
#define CYGONCE_PKGCONF_DEVS_ETH_SMSC_LAN91CXX_H
/*
 * File <pkgconf/devs_eth_smsc_lan91cxx.h>
 *
 * This file is generated automatically by the configuration
 * system. It should not be edited. Any changes to this file
 * may be overwritten.
 */


#endif
