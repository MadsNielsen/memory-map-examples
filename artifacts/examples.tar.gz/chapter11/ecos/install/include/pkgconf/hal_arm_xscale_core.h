#ifndef CYGONCE_PKGCONF_HAL_ARM_XSCALE_CORE_H
#define CYGONCE_PKGCONF_HAL_ARM_XSCALE_CORE_H
/*
 * File <pkgconf/hal_arm_xscale_core.h>
 *
 * This file is generated automatically by the configuration
 * system. It should not be edited. Any changes to this file
 * may be overwritten.
 */

#define CYGSEM_HAL_ARM_XSCALE_BTB 1

#endif
