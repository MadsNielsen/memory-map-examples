#ifndef CYGONCE_PKGCONF_ERROR_H
#define CYGONCE_PKGCONF_ERROR_H
/*
 * File <pkgconf/error.h>
 *
 * This file is generated automatically by the configuration
 * system. It should not be edited. Any changes to this file
 * may be overwritten.
 */

#define CYGPKG_ERROR_ERRNO 1
#define CYGSEM_ERROR_PER_THREAD_ERRNO 1
#define CYGNUM_ERROR_ERRNO_TRACE_LEVEL 0
#define CYGNUM_ERROR_ERRNO_TRACE_LEVEL_0
#define CYGPKG_ERROR_STRERROR 1

#endif
