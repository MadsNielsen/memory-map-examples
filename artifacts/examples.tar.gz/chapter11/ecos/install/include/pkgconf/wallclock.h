#ifndef CYGONCE_PKGCONF_WALLCLOCK_H
#define CYGONCE_PKGCONF_WALLCLOCK_H
/*
 * File <pkgconf/wallclock.h>
 *
 * This file is generated automatically by the configuration
 * system. It should not be edited. Any changes to this file
 * may be overwritten.
 */

#define CYGPKG_WALLCLOCK_EMULATE 1
#undef CYGSEM_WALLCLOCK_SET_GET_MODE
#define CYGPKG_IO_WALLCLOCK_OPTIONS 1

#endif
