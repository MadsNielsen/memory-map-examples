#ifndef CYGONCE_PKGCONF_DEVS_FLASH_STRATA_H
#define CYGONCE_PKGCONF_DEVS_FLASH_STRATA_H
/*
 * File <pkgconf/devs_flash_strata.h>
 *
 * This file is generated automatically by the configuration
 * system. It should not be edited. Any changes to this file
 * may be overwritten.
 */


#endif
