#ifndef CYGONCE_PKGCONF_INFRA_H
#define CYGONCE_PKGCONF_INFRA_H
/*
 * File <pkgconf/infra.h>
 *
 * This file is generated automatically by the configuration
 * system. It should not be edited. Any changes to this file
 * may be overwritten.
 */

/***** proc output start *****/
#include <pkgconf/system.h>
/*****  proc output end  *****/
#define CYGPKG_INFRA_STARTUP 1
#define CYGFUN_INFRA_EMPTY_DELETE_FUNCTIONS 1
#define CYGPKG_INFRA_OPTIONS 1
#define CYGNUM_TESTS_RUN_COUNT 1
#define CYGNUM_TESTS_RUN_COUNT_1

#endif
