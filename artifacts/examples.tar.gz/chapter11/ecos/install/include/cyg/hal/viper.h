#ifndef CYGONCE_HAL_ARM_XSCALE_VIPER_H
#define CYGONCE_HAL_ARM_XSCALE_VIPER_H
//==========================================================================
//
//      viper.h
//
//      Platform specific support (register layout, etc)
//
//==========================================================================
//####ECOSGPLCOPYRIGHTBEGIN####
// -------------------------------------------
// This file is part of eCos, the Embedded Configurable Operating System.
// Copyright (C) 1998, 1999, 2000, 2001, 2002 Red Hat, Inc.
//
// eCos is free software; you can redistribute it and/or modify it under
// the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 or (at your option) any later version.
//
// eCos is distributed in the hope that it will be useful, but WITHOUT ANY
// WARRANTY; without even the implied warranty of MERCHANTABILITY or
// FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
// for more details.
//
// You should have received a copy of the GNU General Public License along
// with eCos; if not, write to the Free Software Foundation, Inc.,
// 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA.
//
// As a special exception, if other files instantiate templates or use macros
// or inline functions from this file, or you compile this file and link it
// with other works to produce a work based on this file, this file does not
// by itself cause the resulting work to be covered by the GNU General Public
// License. However the source code for this file must still be made available
// in accordance with section (3) of the GNU General Public License.
//
// This exception does not invalidate any other reasons why a work based on
// this file might be covered by the GNU General Public License.
//
// Alternative licenses for eCos may be arranged by contacting Red Hat, Inc.
// at http://sources.redhat.com/ecos/ecos-license/
// -------------------------------------------
//####ECOSGPLCOPYRIGHTEND####
//==========================================================================
//#####DESCRIPTIONBEGIN####
//
// Author(s):    <icampbell@arcom.com
// Date:         2003-01-27
//
//####DESCRIPTIONEND####
//
//==========================================================================

#include <pkgconf/system.h>		// System-wide configuration info
#include CYGBLD_HAL_VARIANT_H		// Variant specific configuration
#include CYGBLD_HAL_PLATFORM_H		// Platform specific configuration
#include CYGBLD_HAL_VAR_H		// Platform specific hardware definitions
#include CYGHWR_MEMORY_LAYOUT_H
#include <cyg/hal/hal_pxa2x0.h>           // Applications Processor defines

// VIPER can be any combination of M16-M32-M64 and F8-F16-F32.
// Current is M32-F16.
// Will be in M64-F16 eventually.

// RAM
#define VIPER_SDRAM_BASE		0x00000000
#define VIPER_SDRAM_UNCACHED_BASE	0xC0000000

// Cache flush region
#undef  DCACHE_FLUSH_AREA
#define DCACHE_FLUSH_AREA   0xe0000000

// Flash
#ifndef CYGHWR_REVERSE_FLASH_LOCATION
# define VIPER_AMD_FLASH_BASE		0x50000000
# define VIPER_INTEL_FLASH_BASE		0x60000000
#else
# define VIPER_INTEL_FLASH_BASE		0x50000000
# define VIPER_AMD_FLASH_BASE		0x60000000
#endif

// Compact Flash
#define VIPER_CF_DETECT			CYGNUM_HAL_INTERRUPT_GPIO32
#define VIPER_CF_IRQ			CYGNUM_HAL_INTERRUPT_GPIO8

#define VIPER_CF_MEM_BASE		(PXA2X0_PCMCIA0_BASE + 0x0C000000)
#define VIPER_CF_ATTR_BASE		(PXA2X0_PCMCIA0_BASE + 0x08000000)
#define VIPER_CF_IO_BASE		(PXA2X0_PCMCIA0_BASE + 0x00000000)

#define VIPER_GPIO_CF_DETECT       	0x00000001     // 0 = Compact Flash detect. GPLR1.
#define VIPER_GPIO_CF_PRESENT      	0x00000000
#define VIPER_GPIO_CF_ABSENT       	0x00000001

#define VIPER_GPIO_CF_RDY		0x00000080     // GPLR0, GPIO 8

#define VIPER_GPIO_CF_POWER		0x00040000     // GPIO82

// Ethernet
#define VIPER_ETH_BASE			(PXA2X0_CS2_BASE + 0x300)
#define VIPER_ETH_DATA_BASE	 	PXA2X0_CS4_BASE
#define VIPER_ETH_IRQ			CYGNUM_HAL_INTERRUPT_GPIO0

// CPLD
#define VIPER_CPLD_BASE			PXA2X0_CS5_BASE
#define VIPER_ICR			(VIPER_CPLD_BASE + 0x100002) /* Interrupt Control Register */
#define   VIPER_ICR_RETRIG		(1 << 0)
#define   VIPER_ICR_AUTO_CLR		(1 << 1)
#define   VIPER_ICR_R_DIS		(1 << 2)
#define   VIPER_ICR_CF_RST		(1 << 3)

#ifndef __ASSEMBLER__
void viper_program_new_stack(void *func);
void viper_user_hardware_init(void);
#endif




#endif //CYGONCE_HAL_ARM_XSCALE_VIPER_H
