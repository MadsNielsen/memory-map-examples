/*=============================================================================
//
//      hal_platform_setup.h
//
//      Platform specific support for HAL (assembly code)
//
//==========================================================================
//####ECOSGPLCOPYRIGHTBEGIN####
// -------------------------------------------
// This file is part of eCos, the Embedded Configurable Operating System.
// Copyright (C) 1998, 1999, 2000, 2001, 2002 Red Hat, Inc.
//
// eCos is free software; you can redistribute it and/or modify it under
// the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 or (at your option) any later version.
//
// eCos is distributed in the hope that it will be useful, but WITHOUT ANY
// WARRANTY; without even the implied warranty of MERCHANTABILITY or
// FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
// for more details.
//
// You should have received a copy of the GNU General Public License along
// with eCos; if not, write to the Free Software Foundation, Inc.,
// 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA.
//
// As a special exception, if other files instantiate templates or use macros
// or inline functions from this file, or you compile this file and link it
// with other works to produce a work based on this file, this file does not
// by itself cause the resulting work to be covered by the GNU General Public
// License. However the source code for this file must still be made available
// in accordance with section (3) of the GNU General Public License.
//
// This exception does not invalidate any other reasons why a work based on
// this file might be covered by the GNU General Public License.
//
// Alternative licenses for eCos may be arranged by contacting Red Hat, Inc.
// at http://sources.redhat.com/ecos/ecos-license/
// -------------------------------------------
//####ECOSGPLCOPYRIGHTEND####
//==========================================================================
//#####DESCRIPTIONBEGIN####
//
// Author(s):    <knud.woehler@microplex.de>
// Date:         2003-01-09
//
//####DESCRIPTIONEND####
//
//===========================================================================*/
#ifndef CYGONCE_HAL_PLATFORM_SETUP_H
#define CYGONCE_HAL_PLATFORM_SETUP_H

#include <pkgconf/system.h>		// System-wide configuration info
#include CYGBLD_HAL_VARIANT_H		// Variant specific configuration
#include CYGBLD_HAL_PLATFORM_H		// Platform specific configuration
#include CYGBLD_HAL_VAR_H		// Platform specific hardware definitions
#include <cyg/hal/hal_mmu.h>		// MMU definitions
#include <cyg/hal/hal_mm.h>		// more MMU definitions
#include <cyg/hal/viper.h>

#define GPSR0_OFFS		(PXA2X0_GPSR0-PXA2X0_GPIO_BASE)
#define GPCR0_OFFS		(PXA2X0_GPCR0-PXA2X0_GPIO_BASE)
#define GPSR1_OFFS		(PXA2X0_GPSR1-PXA2X0_GPIO_BASE)
#define GPCR1_OFFS		(PXA2X0_GPCR1-PXA2X0_GPIO_BASE)
#define GPSR2_OFFS		(PXA2X0_GPSR2-PXA2X0_GPIO_BASE)
#define GPCR2_OFFS		(PXA2X0_GPCR2-PXA2X0_GPIO_BASE)
#define GPDR0_OFFS		(PXA2X0_GPDR0-PXA2X0_GPIO_BASE)
#define GPDR1_OFFS		(PXA2X0_GPDR1-PXA2X0_GPIO_BASE)
#define GPDR2_OFFS		(PXA2X0_GPDR2-PXA2X0_GPIO_BASE)
#define GAFR0_L_OFFS		(PXA2X0_GAFR0_L-PXA2X0_GPIO_BASE)
#define GAFR0_U_OFFS		(PXA2X0_GAFR0_U-PXA2X0_GPIO_BASE)
#define GAFR1_L_OFFS		(PXA2X0_GAFR1_L-PXA2X0_GPIO_BASE)
#define GAFR1_U_OFFS		(PXA2X0_GAFR1_U-PXA2X0_GPIO_BASE)
#define GAFR2_L_OFFS		(PXA2X0_GAFR2_L-PXA2X0_GPIO_BASE)
#define GAFR2_U_OFFS		(PXA2X0_GAFR2_U-PXA2X0_GPIO_BASE)
#define PSSR_OFFS		(PXA2X0_PSSR-PXA2X0_PM_BASE)
#define PSPR_OFFS		(PXA2X0_PSPR-PXA2X0_PM_BASE)
#define RCSR_OFFS		(PXA2X0_RCSR-PXA2X0_PM_BASE)

#define RCSR_SMR		0x04 // Sleep mode

#define PSSR_RDH		0x20 // Read Disable Hold
#define PSSR_PH                        0x10 // Peripheral Control Hold

/**********************************************************************
* Utilities
**********************************************************************/
#define OSCR_OFFS (PXA2X0_OSCR-PXA2X0_OSTIMER_BASE)

	.macro wait_200_usec
		// wait 200 usec
		ldr	r4,	=PXA2X0_OSTIMER_BASE		// set OS Timer Count
		mov	r0,	#0
		str	r0,	[r4, #OSCR_OFFS]
		ldr	r2,	=0x300				// wait 200 usec
61:
		ldr	r0,	[r4, #OSCR_OFFS]
		cmp	r2,	r0
		bgt	61b
	.endm

/**********************************************************************
* MMU/Cache
**********************************************************************/
.macro init_mmu_cache_on

		early_uart_out r0, r2, '.'

		ldr	r0, =0x2001
		mcr	p15, 0, r0, c15, c1, 0
		mcr	p15, 0, r0, c7, c10, 4		// drain the write & fill buffers
		CPWAIT	r0
		mcr	p15, 0, r0, c7, c7, 0		// flush Icache, Dcache and BTB
		CPWAIT	r0
		mcr	p15, 0, r0, c8, c7, 0		// flush instuction and data TLBs
		CPWAIT	r0

		early_uart_out r0, r2, '.'

		// Icache on
		mrc	p15, 0, r0, c1, c0, 0
		orr	r0, r0, #MMU_Control_I
                orr	r0, r0, #MMU_Control_BTB
		mcr	p15, 0, r0, c1, c0, 0
		CPWAIT	r0

		early_uart_out r0, r2, '.'

                // Set up a stack [for calling C code]
                ldr     r1,=__startup_stack
                ldr     r2,=PXA2X0_RAM_BANK0_BASE
                orr     sp,r1,r2

                // Create MMU tables
                bl      hal_mmu_init

		early_uart_out r0, r2, '.'

		// MMU on
		ldr     r2,=1f
		mrc	p15, 0, r0, c1, c0, 0
                orr	r0, r0, #MMU_Control_M
                orr	r0, r0, #MMU_Control_R
                mcr     p15, 0, r0, c1, c0, 0
		mov	pc,r2
		nop
		nop
		nop
1:

		early_uart_out r0, r2, '.'

		mcr	p15, 0, r0, c7, c10, 4		// drain the write & fill buffers
		CPWAIT	r0

		early_uart_out r0, r2, '.'

		// Dcache on
		mrc	p15, 0, r0, c1, c0, 0
		orr	r0, r0, #MMU_Control_C
		mcr	p15, 0, r0, c1, c0, 0
		CPWAIT	r0

		early_uart_out r0, r2, '.'

		// clean/drain/flush the main Dcache
		mov	r1, #0xe0000000
		mov	r0, #1024
2:
		mcr	p15, 0, r1, c7, c2, 5
		add	r1, r1, #32
		subs	r0, r0, #1
		bne	2b

		early_uart_out r0, r2, '.'

		// clean/drain/flush the mini Dcache
		mov	r0, #64					// number of lines in the mini Dcache
3:
		mcr	p15, 0, r1, c7, c2, 5			// allocate a Dcache line
		add	r1, r1, #32				// increment the address to
		subs	r0, r0, #1				// decrement the loop count
		bne	3b

		early_uart_out r0, r2, '.'

		// flush Dcache
		mcr	p15, 0, r0, c7, c6, 0
		CPWAIT	r0

		// drain the write & fill buffers
		mcr	p15, 0, r0, c7, c10, 4
		CPWAIT	r0
.endm

/**********************************************************************
* Clock
**********************************************************************/

#define PSU_DATA	0x00000040
#define PSU_CLK		0x00000800
#define PSU_LD		0x00080000
.macro init_vcore
		// Configure voltage scaler to maximum voltage (divisor 0x000)
	        ldr	r1, =PXA2X0_GPIO_BASE

		// ... Clear CLK and LD pins
		ldr	r0, =(PSU_CLK|PSU_LD)
		str	r0, [r1, #GPCR0_OFFS]

		// ... Set DATA
		ldr	r0, =(PSU_DATA)
		str	r0, [r1, #GPSR0_OFFS]

		// ... Clock 12 zeros into shift register
		mov	r5, #(PSU_CLK)
		mov	r3, #12
1:		str	r5, [r1, #GPSR0_OFFS]
		wait_200_usec
		str	r5, [r1, #GPCR0_OFFS]
		wait_200_usec
		sub	r3, r3, #1
		cmp	r3, #0
		bgt	1b

		// ... Latch values into divisor
		mov	r0, #PSU_LD
		str	r0, [r1, #GPSR0_OFFS]
		wait_200_usec
		str	r0, [r1, #GPCR0_OFFS]

.endm

/**********************************************************************
* Interrupt controller
**********************************************************************/
#define ICLR_OFFS (PXA2X0_ICLR-PXA2X0_IC_BASE)
#define ICMR_OFFS (PXA2X0_ICMR-PXA2X0_IC_BASE)

.macro init_intc_cnt
		ldr	r1, =PXA2X0_IC_BASE
		mov	r0, #0
		str	r0, [r1, #ICLR_OFFS]			// clear Interrupt level Register
		str	r0, [r1, #ICMR_OFFS]			// clear Interrupt mask Register
.endm

/**********************************************************************
* SDRAM
**********************************************************************/
#define MDCNFG_DE0	0x00000001
#define MDCNFG_DE1	0x00000002
#define MDCNFG_DE2	0x00010000
#define MDCNFG_DE3	0x00020000

/* columns */
#define MDCNFG_DCAC0_8	0x00000000
#define MDCNFG_DCAC0_9	0x00000008
#define MDCNFG_DCAC0_10	0x00000010
#define MDCNFG_DCAC0_11	0x00000018

/* rows */
#define MDCNFG_DRAC0_11	0x00000000
#define MDCNFG_DRAC0_12	0x00000020
#define MDCNFG_DRAC0_13	0x00000040

/* banks */
#define MDCNFG_DNB0_2	0x00000000
#define MDCNFG_DNB0_4	0x00000080

#define MDCNFG_DLATCH0	0x00000800
#define MDCNFG_SA1111_0 0x00001000

/* base configuration before columns and rows are determined */
#define MDCNFG_BASE	(0x100|MDCNFG_DE0|MDCNFG_DNB0_4|MDCNFG_DLATCH0|MDCNFG_SA1111_0)

#define MDREFR_VAL	( MDREFR_K0RUN | MDREFR_K0DB2 | MDREFR_E0PIN | MDREFR_K0FREE \
			| MDREFR_K1RUN                | MDREFR_E1PIN                 \
			               | MDREFR_K2DB2                                \
			| 0x17 )

#define MDMRS_VAL	0x00000000	// SDRAM Mode Reg Set Config Reg
#define SXCNFG_VAL	0x00000000	// No sync static memory

/* CS 0,1,2,3 and 5 are 16 bit.
 * CS 4 is 32 bit.
 *
 * CS 0 and 1 are ROM/Flash memory
 * CS 2,3,4,5 are VLIO
 */
#ifndef CYGHWR_REVERSE_FLASH_LOCATION
#define MSC0_VAL	0x22DA2888	// CS1(Flash)0/CS0(Boot).
#else
/* Dont bother optimising this case since it is only for emergency recovery */
#  define MSC0_VAL	0x7FF87FF8	// CS1(Boot)0/CS0(Flash).
#endif
#define MSC1_VAL	0x44FC123C	// CS3(USBCS)/CS2(ETH_CS2).
#define MSC2_VAL	0x266c1234	// CS5(CPLDCS)/CS4(ETH_CS1).

#define MECR_VAL   	0x00000001
#define MCMEM0_VAL 	0x0002449A
#define MCMEM1_VAL 	0x00014511
#define MCATT0_VAL 	0x0002851F
#define MCATT1_VAL 	0x00014511
#define MCIO0_VAL  	0x00018312
#define MCIO1_VAL  	0x00014511

#define OSCR_OFFS	(PXA2X0_OSCR-PXA2X0_OSTIMER_BASE)
#define MDREFR_OFFS	(PXA2X0_MDREFR-PXA2X0_MEMORY_CTL_BASE)
#define MDCNFG_OFFS	(PXA2X0_MDCNFG-PXA2X0_MEMORY_CTL_BASE)
#define MDMRS_OFFS	(PXA2X0_MDMRS-PXA2X0_MEMORY_CTL_BASE)
#define MSC0_OFFS	(PXA2X0_MSC0-PXA2X0_MEMORY_CTL_BASE)
#define MSC1_OFFS	(PXA2X0_MSC1-PXA2X0_MEMORY_CTL_BASE)
#define MSC2_OFFS	(PXA2X0_MSC2-PXA2X0_MEMORY_CTL_BASE)
#define MECR_OFFS	(PXA2X0_MECR-PXA2X0_MEMORY_CTL_BASE)
#define MCMEM0_OFFS	(PXA2X0_MCMEM0-PXA2X0_MEMORY_CTL_BASE)
#define MCMEM1_OFFS	(PXA2X0_MCMEM1-PXA2X0_MEMORY_CTL_BASE)
#define MCATT0_OFFS	(PXA2X0_MCATT0-PXA2X0_MEMORY_CTL_BASE)
#define MCATT1_OFFS	(PXA2X0_MCATT1-PXA2X0_MEMORY_CTL_BASE)
#define MCIO0_OFFS	(PXA2X0_MCIO0-PXA2X0_MEMORY_CTL_BASE)
#define MCIO1_OFFS	(PXA2X0_MCIO1-PXA2X0_MEMORY_CTL_BASE)
#define SXCNFG_OFFS	(PXA2X0_SXCNFG-PXA2X0_MEMORY_CTL_BASE)

#define MDREFR_K2FREE	0x02000000
#define MDREFR_K1FREE	0x01000000
#define MDREFR_K0FREE	0x00800000
#define MDREFR_SLFRSH	0x00400000
#define MDREFR_APD	0x00100000
#define MDREFR_K2DB2	0x00080000
#define MDREFR_K2RUN	0x00040000
#define MDREFR_K1DB2	0x00020000
#define MDREFR_K1RUN	0x00010000
#define MDREFR_E1PIN	0x00008000
#define MDREFR_K0DB2	0x00004000
#define MDREFR_K0RUN	0x00002000
#define MDREFR_E0PIN	0x00001000
#define MDREFR_DRI_MASK	0x00000FFF
#define MDREFR_INIT_MASK	(MDREFR_SLFRSH | MDREFR_APD)

	.macro init_sdram_cnt
		ldr     r1,  =PXA2X0_MEMORY_CTL_BASE

	        // write MSC registers, read back to ensure data latches

	        ldr     r0,  =MSC0_VAL
	        str     r0,  [r1, #MSC0_OFFS]
	        ldr     r0,  [r1, #MSC0_OFFS]
	        ldr     r0,  =MSC1_VAL
	        str     r0,  [r1, #MSC1_OFFS]
	        ldr     r0,  [r1, #MSC1_OFFS]
	        ldr     r0,  =MSC2_VAL
	        str     r0,  [r1, #MSC2_OFFS]
	        ldr     r0,  [r1, #MSC2_OFFS]

	        ldr     r0,  =MECR_VAL
	        str     r0,  [r1, #MECR_OFFS]

	        ldr     r0,  =MCMEM0_VAL
	        str     r0,  [r1, #MCMEM0_OFFS]
	        ldr     r0,  =MCMEM1_VAL
	        str     r0,  [r1, #MCMEM1_OFFS]

	        ldr     r0,  =MCATT0_VAL
	        str     r0,  [r1, #MCATT0_OFFS]
	        ldr     r0,  =MCATT1_VAL
	        str     r0,  [r1, #MCATT1_OFFS]

	        ldr     r0,  =MCIO0_VAL
	        str     r0,  [r1, #MCIO0_OFFS]
	        ldr     r0,  =MCIO1_VAL
	        str     r0,  [r1, #MCIO1_OFFS]

		// Synchronous static memory.
		mov	r0, #SXCNFG_VAL
		str	r0, [r1, #SXCNFG_OFFS]

		// Load MDREFR and retain the values of APD and SLFRFSH.
		ldr	r0, [r1, #MDREFR_OFFS]
		ldr	r2, =MDREFR_INIT_MASK           // Save APD & SLFRSH
		and	r0, r0, r2

		// Load MDREFR settings. Disable E1PIN for now.
		ldr	r2, =MDREFR_VAL
		orr	r0, r0, r2
		bic	r0, r0, #MDREFR_E1PIN
		str	r0, [r1, #MDREFR_OFFS]

		// De-assert self refresh. (Self refresh -> Power down)
		orr	r0, r0, r2
		bic	r0, r0, #MDREFR_SLFRSH
		bic	r0, r0, #MDREFR_E1PIN
		str	r0, [r1, #MDREFR_OFFS]

		// Assert E[01]PIN (Power down -> PWRDWNX). The SDRAM controller
		// will transition the devices from PWRDWNX -> NOP without any
		// additional writes.
		orr	r0, r0, r2
		str	r0, [r1, #MDREFR_OFFS]

		// configure for max size, but don't enable any of the banks.
		ldr		r0, =(MDCNFG_DRAC0_13|MDCNFG_DCAC0_9|MDCNFG_BASE)
		mov             r2, #(MDCNFG_DE0|MDCNFG_DE1)
		orr		r2, r2, #(MDCNFG_DE2|MDCNFG_DE3)
		mvn		r2, r2
		and		r0, r0, r2
		str		r0, [r1, #MDCNFG_OFFS]

		wait_200_usec

		// Do a series of 8 reads from un-enabled SDRAM.  The read from unenabled SDRAM
		// causes a simultaneous CBR to all four banks.  On the first pass, a PALL
		// (precharge All) is sent.
		ldr		r4, =0xA0000000 // BANK0
		ldr		r5, [r4], #4					// Do the 8 reads.
		ldr		r5, [r4], #4
		ldr		r5, [r4], #4
		ldr		r5, [r4], #4
		ldr		r5, [r4], #4
		ldr		r5, [r4], #4
		ldr		r5, [r4], #4
		ldr		r5, [r4], #4
		ldr		r5, [r4], #4

		// Now write the MDCNFG register with the enable bits set.
		ldr		r0, =(MDCNFG_BASE | MDCNFG_DRAC0_13 | MDCNFG_DCAC0_9)
		str		r0, [r1, #MDCNFG_OFFS]

		// Issue a MRS command to the SDRAM.
		ldr		r0, =MDMRS_VAL
		str		r0, [r1, #MDMRS_OFFS]

	/* SDRAM sizing algorithm based on the one described in the
	 * AMD Ãlan SC520 Microcontroller User's Manual, chapter 10 */

	/* The SDRAM controller is configured for 2x13x9x32.
	 * This means that the RAS/CAS generated by these addresses
	 * are aliased as shown when the actual hardware has a different
	 * arrangement
         *
         * We save the initial values and restore them after detection
         * because we might be resuming from sleep and so the orignal
         * data could be important!
         */
	                      /* RAS   CAS | 9 COLS  8 COLS 	PRESERVED */
#define COL9_ADDR  0xA2000380 /* 0000  1E0 | 1E0     0E0	r9 */
#define COL8_ADDR  0xA0000380 /* 0000  0E0 | 0E0     0E0	r8 */

#define COL9_DATA  0x09090909 // MDCNFG |= 0x0008 [ == ( 9 - 8 ) << 3 ]
#define COL8_DATA  0x08080808 // MDCNFG |= 0x0000 [ == ( 8 - 8 ) << 3 ]

                              /* RAS   CAS | 13 ROWS  12 ROWS  11 ROWS	PRESERVED */
#define ROW13_ADDR 0xA1380000 /* 1E00  000 | 1E00     0E00     0600	r12 */
#define ROW12_ADDR 0xA0380000 /* 0E00  000 | 0E00     0E00     0600	r11 */
#define ROW11_ADDR 0xA0180000 /* 0600  000 | 0600     0600     0600	r10 */

#define ROW13_DATA 0x0D0D0D0D // MDCNFG |= 0x0060 [ == ( 13 - 11 ) << 5 ]
#define ROW12_DATA 0x0C0C0C0C // MDCNFG |= 0x0040 [ == ( 12 - 11 ) << 5 ]
#define ROW11_DATA 0x0B0B0B0B // MDCNFG |= 0x0000 [ == ( 11 - 11 ) << 5 ]

		ldr	r5, =COL9_ADDR
		ldr	r9, [r5]
		ldr	r6, =COL9_DATA
		str	r6, [r5]
		ldr	r7, [r5]
		cmp	r6, r7
		bne	badram

		ldr	r5, =COL8_ADDR
		ldr	r8, [r5]
		ldr	r6, =COL8_DATA
		str	r6, [r5]
		ldr	r7, [r5]
		cmp	r6, r7
		bne	badram

		ldr	r5, =ROW13_ADDR
		ldr	r12, [r5]
		ldr	r6, =ROW13_DATA
		str	r6, [r5]
		ldr	r7, [r5]
		cmp	r6, r7
		bne	badram

		ldr	r5, =ROW12_ADDR
		ldr	r11, [r5]
		ldr	r6, =ROW12_DATA
		str	r6, [r5]
		ldr	r7, [r5]
		cmp	r6, r7
		bne	badram

		ldr	r5, =ROW11_ADDR
		ldr	r10, [r5]
		ldr	r6, =ROW11_DATA
		str	r6, [r5]
		ldr	r7, [r5]
		cmp	r6, r7
		bne	badram

		ldr	r3, =(MDCNFG_BASE)

		// read back COL9_ADDR for # of columns
		ldr	r5, =COL9_ADDR
		ldr	r5, [r5]
		and	r5, r5, #0xff
		sub	r5, r5, #8
		orr	r3, r3, r5, lsl #3

		// read back ROW13_ADDR for # of rows
		ldr	r5, =ROW13_ADDR
		ldr	r5, [r5]
		and	r5, r5, #0xff
		sub	r5, r5, #11
		orr	r3, r3, r5, lsl #5

		// r3 should equal proposed MDCNFG at this point

		// restore the original data before going any further. in reverse order to above
		// so that we restore the aliased data correctly.
		ldr	r5, =ROW11_ADDR
		str	r10, [r5]
		ldr	r5, =ROW12_ADDR
		str	r11, [r5]
		ldr	r5, =ROW13_ADDR
		str	r12, [r5]
		ldr	r5, =COL8_ADDR
		str	r8, [r5]
		ldr	r5, =COL9_ADDR
		str	r9, [r5]

		b	goodram

badram: // not much can be done here really. hardcode the most common/likely
		ldr	r3, =(MDCNFG_BASE | MDCNFG_DRAC0_13 | MDCNFG_DCAC0_9) // 64M
		//ldr	r3, =(MDCNFG_BASE | MDCNFG_DRAC0_12 | MDCNFG_DCAC0_9) // 32M
		//ldr	r3, =(MDCNFG_BASE | MDCNFG_DRAC0_12 | MDCNFG_DCAC0_8) // 16M
goodram:

		// Properly configure but don't enable any of the banks.  This code will mask out all of the
		// enables before writing to the MDCNFG register.
		mov		r0, r3
		mov             r2, #(MDCNFG_DE0|MDCNFG_DE1)
		orr		r2, r2, #(MDCNFG_DE2|MDCNFG_DE3)
		mvn		r2, r2
		and		r0, r0, r2
		str		r0, [r1, #MDCNFG_OFFS]

		wait_200_usec

		// Do a series of 8 reads from un-enabled SDRAM.  The read from unenabled SDRAM
		// causes a simultaneous CBR to all four banks.  On the first pass, a PALL
		// (precharge All) is sent.
		ldr		r4, =0xA0000000 // BANK0
		ldr		r5, [r4], #4					// Do the 8 reads.
		ldr		r5, [r4], #4
		ldr		r5, [r4], #4
		ldr		r5, [r4], #4
		ldr		r5, [r4], #4
		ldr		r5, [r4], #4
		ldr		r5, [r4], #4
		ldr		r5, [r4], #4
		ldr		r5, [r4], #4

		// Now write the MDCNFG register with the enable bits set.
		mov		r0, r3
		str		r0, [r1, #MDCNFG_OFFS]

		// Issue a MRS command to the SDRAM.
		ldr		r0, =MDMRS_VAL
		str		r0, [r1, #MDMRS_OFFS]
	.endm

/**********************************************************************
* GPIOs
**********************************************************************/

//   GPIO	Name		Pin	GPDR	GAFR	GPSR
//					1=out		1=set

//	0	ETHER_INT	L10	0	00	0
//	1	CPLD_INT	L12	0	00	0
//	2	USB_INT		L13	0	00	0
//	3	UART_INT1	K14	0	00	0

//	4	UART_INT2	J12	0	00	0
//	5	BATTERY_MODE2	J11	0	00	0	LK2
//	6	PSU_DATA	H14	1	00	0
//	7	CPLDIO1/LK3	G15	0	00	0

//	8	CF_RDY		F14	0	00	0
//	9	BLKEN#		F12	1	00	0
//	10	LCDEN#		F7	1	00	0
//	11	PSU_CLK		A7	1	00	0

//	12	SHDN		B6	1	00	0
//	13	USB H_WAKEUP	B5	1	00	0
//	14	FLASH_STATUS	B4	0	00	0
//	15	nCS_1		T8	1	10	1

#define GAFR0_L_VAL		0x80000000

//	16	PWM0		E12	1	10	1
//	17	PWM1		D12	1	10	1
//	18	RDY		C1	0	01	0
//	19	PSU_IO		N14	1	00	0

//	20	OUT0/#PWRDOWN	N12	1	00	0
//	21	OUT1		N15	1	00	1
//	22	OUT2		M12	1	00	1
//	23	OUT3		F9	1	00	1

//	24	OUT4		E9	1	00	1
//	25	OUT5		D9	1	00	1
//	26	OUT6		A9	1	00	1
//	27	OUT7		B9	1	00	1

//	28	BITCLK		C9	0	01	1
//	29	SDATIN0		E10	0	01	0
//	30	SDATOUT		A10	1	10	1
//	31	SYNC		E11	1	10	1

#define GPDR0_VAL		0xCFFBBE40
#define GAFR0_U_VAL		0xA500001A
#define GPSR0_VAL		0xDFE38000

//	32	SDATIN1		A16	0	00	0
//	33	nCS[5]		T13	1	10	1
//	34	FFRXD		A13	0	01	0
//	35	FFCTS		A14	0	01	0

//	36	FFDCD		A12	0	01	0
//	37	FFDSR		B11	0	01	0
//	38	FFRI		B10	0	01	0
//	39	FFTXD		E13	1	10	1

//	40	FFDTR		F10	1	10	1
//	41	FFRTS		F8	1	10	1
//	42	BTRXD		B13	0	01	0
//	43	BTTXD		D13	1	10	1

//	44	BTCTS		A15	0	01	0
//	45	BTRTS		B14	1	10	1
//	46	STRXD		B15	0	10	0
//	47	STTXD		C15	1	01	1

#define GAFR1_L_VAL		0x699A9558

//	48	nPOE 		P13	1	10	1
//	49	nPWE		T14	1	10	1
//	50	nPIOR		T15	1	10	1
//	51	nPIOW		R15	1	10	1

//	52	nPCE[1]		P14	1	10	1
//	53	nPCE[2]		R16	1	10	1
//	54	nPSKTSEL	P16	1	10	1
//	55	nPREG		M13	1	10	1

//	56	nPWAIT		N16	0	01	0
//	57	nIOIS16		M16	0	01	0
//	58	LCDD0		E7	1	10	1
//	59	LCDD1		D7	1	10	1

//	60	LCDD2		C7	1	10	1
//	61	LCDD3		B7	1	10	1
//	62	LCDD4		E6	1	10	1
//	63	LCDD5		D6	1	10	1

#define GPDR1_VAL		0xFCFFAB82
#define GAFR1_U_VAL		0xAAA5AAAA
#define GPSR1_VAL		0xFCFFAB82

//	64	LCDD6		E5	1	10	1
//	65	LCDD7		A6	1	10	1
//	66	LCDD8		C5	1	10	1
//	67	LCDD9		A5	1	10	1

//	68	LCDD10		D5	1	10	1
//	69	LCDD11		A4	1	10	1
//	70	LCDD12		A3	1	10	1
//	71	LCDD13		A2	1	10	1

//	72	LCDD14		C3	1	10	1
//	73	LCDD15		B3	1	10	1
//	74	LCDFCLK		E8	1	10	1
//	75	LCDLCLK		D8	1	10	1

//	76	LCDPCLK		B8	1	10	1
//	77	LCDBIAS		A8	1	10	1
//	78	nCS[2]		P9	1	10	1
//	79	nCS[3]		T9	1	10	1

#define GAFR2_L_VAL		0xAAAAAAAA

//	80	nCS[4]		R13	0	10	0
//	81	MEMSIZE		F16	0	00	0	0==M64 1==M16
//	82	CF_SWITCH	E16	1	00	0
//	83	RTC_IO		E15	0	00	0

//	84			D16	0	00	0	RTC_CLK

#define GPDR2_VAL		0x0004FFFF
#define GAFR2_U_VAL		0x00000002
#define GPSR2_VAL		0x0000FFFF

.macro init_gpio
	        ldr		r1, =PXA2X0_GPIO_BASE

		ldr		r0, =GPSR0_VAL			// set GPIO outputs to default
	        str		r0, [r1, #GPSR0_OFFS]
		mvn		r0, r0
		str		r0, [r1, #GPCR0_OFFS]
		ldr		r0, =GPSR1_VAL			// set GPIO outputs to default
	        str		r0, [r1, #GPSR1_OFFS]
		mvn		r0, r0
	        str		r0, [r1, #GPCR1_OFFS]
	        ldr		r0, =GPSR2_VAL			// set GPIO outputs to default
	        str		r0, [r1, #GPSR2_OFFS]
		mvn		r0, r0
		str		r0, [r1, #GPCR2_OFFS]

		ldr		r0, =GPDR0_VAL			// GPIO direction
		str		r0, [r1, #GPDR0_OFFS]
		ldr		r0, =GPDR1_VAL			// GPIO direction
		str		r0, [r1, #GPDR1_OFFS]
		ldr		r0, =GPDR2_VAL			// GPIO direction
		str		r0, [r1, #GPDR2_OFFS]

	        ldr		r0, =GAFR0_L_VAL		// GPIO alternate function
	        str		r0, [r1, #GAFR0_L_OFFS]
	        ldr		r0, =GAFR0_U_VAL		// GPIO alternate function
	        str		r0, [r1, #GAFR0_U_OFFS]
	        ldr		r0, =GAFR1_L_VAL		// GPIO alternate function
	        str		r0, [r1, #GAFR1_L_OFFS]
	        ldr		r0, =GAFR1_U_VAL		// GPIO alternate function
	        str		r0, [r1, #GAFR1_U_OFFS]
	        ldr		r0, =GAFR2_L_VAL		// GPIO alternate function
	        str		r0, [r1, #GAFR2_L_OFFS]
	        ldr		r0, =GAFR2_U_VAL		// GPIO alternate function
	        str		r0, [r1, #GAFR2_U_OFFS]

	        ldr		r1, =PXA2X0_PM_BASE
		mov		r0, #PSSR_RDH
		str		r0, [r1, #PSSR_OFFS]	// enable GPIO inputs

.endm

.macro early_uart_init
		ldr	r0, =PXA2X0_FFUART_BASE

		// Disable UART and disable interrupts
		ldr	r1, =0
		str	r1,[r0,#0x0c]	// DLAB_OFF
		str	r1,[r0,#0x04]	// IER_DLH = 0x0

		// Set baud rate divisor
		ldr	r1, =0x80
		str	r1, [r0,#0x0c]	// DLAB on
		ldr	r1, =0x8	// 115200
		str	r1, [r0]	// THR_RBR_DLL = ....
		ldr	r1, =0x0
		str	r1, [r0,#0x04]	// IER_DLH = 0x0

		// Set parameters to 8,N,1
		ldr	r1, =0x0
		str	r1, [r0, #0x0c]	// DLAB off
		ldr	r1, =0x3
		str	r1, [r0, #0x0c]	// LCR = 0x3

		// Set polled mode
		ldr	r1, =0x0
		str	r1, [r0, #0x04]	// IER_DLH = 0x0

		// Set normal UART mode
		ldr	r1, =0x0
		str	r1, [r0, #0x10]	// MCR = 0x0

		// Enable UART
		ldr	r1, [r0, #0x04]
		orr	r1, r1, #0x40
		str	r1, [r0, #0x04]

		ldr	r1, =0xc1
		str	r1, [r0, #0x08]
		ldr	r1, =0xc3
		str	r1, [r0, #0x08]
		ldr	r1, =0x05
		str	r1, [r0, #0x08]
.endm

#if 0
.macro early_uart_out T0, T1, x
	ldr	\T0, =PXA2X0_FFUART_BASE
	mov	\T1, #\x
	str	\T1, [\T0]
.endm
#else
.macro early_uart_out T0, T1, x
.endm
#endif

/**********************************************************************
* Wake up from sleep mode
**********************************************************************/

	.macro wake_from_sleep

	ldr	r1, =PXA2X0_PM_BASE

	// Check if this is a Sleep Mode Reset
	ldr	r0, [r1, #RCSR_OFFS]
	ands	r0, r0, #RCSR_SMR
	beq	1f

	// Clear sleep mode bit to avoid loop
	str	r0, [r1, #RCSR_OFFS]

	// Check PSSR_VFS and PSSR_BFS and potentially do a normal
	// reset instead of wake.

        // resume address is stored in PSPR if PSPR is 0 then assume
        // we have not gone to sleep gracefully and continue with a
        // normal reset
        ldr     r0, [r1, #PSPR_OFFS]
        teq     r0, #0
        movne   pc, r0

        // We are waking from a VBATT_FAULT sleep. So clear PSSR_PH in
        // order to continue with a regular reset.
        mov     r0, #PSSR_PH
        str     r0, [r1, #PSSR_OFFS]
1:
.endm


/**********************************************************************
* LED
**********************************************************************/
// There are no LEDs on the VIPER, so we dump a hex character to the FFUART
#if 0
#define CYGHWR_LED_MACRO		 	 \
        b               2f                      ;\
1:                                              ;\
        .byte 0x30, 0x31, 0x32, 0x33		;\
        .byte 0x34, 0x35, 0x36, 0x37		;\
        .byte 0x38, 0x39, 0x41, 0x42		;\
        .byte 0x43, 0x44, 0x45, 0x46	        ;\
2:                                              ;\
        sub	r1, pc, #((3f+4)-1b)		;\
3:                                              ;\
        ldrb	r1, [r1, #\x]			;\
	ldr	r0, =PXA2X0_FFUART_BASE		;\
        str	r1, [r0]			;
#else
#define CYGHWR_LED_MACROS
#endif

/**********************************************************************
* initialize controller
**********************************************************************/

#if defined(CYG_HAL_STARTUP_ROM) || defined(CYG_HAL_STARTUP_ROMRAM)
#define PLATFORM_SETUP1 _platform_setup1
#define CYGHWR_HAL_ARM_HAS_MMU
#else
#define PLATFORM_SETUP1
#endif

.macro _platform_setup1
	// disable MMU and cache
	mov	r0, #0x78
	mcr	p15, 0, r0, c1, c0, 0

	// invalidate I&D cache & BTB
	mcr	p15, 0, r0, c7, c7, 0	// r0 ignored

	// drain write (& fill) buffer
	mcr	p15, 0, r0, c7, c10, 4 	// r0 ignored

	CPWAIT	r0

	// there is only one co processor on the PXA25x
	ldr	r0, =0x0000001
	mcr	p15, 0, r0, c3, c0, 0

	init_sdram_cnt

	// Wake up from sleep if necessary.
	wake_from_sleep

	init_gpio

	early_uart_init

	LED(11)
	init_intc_cnt			// Interrupt Controller
	LED(10)
	init_vcore			// Core voltage
	LED(9)
	init_mmu_cache_on		// MMU and Cache
	LED(8)
.endm

#endif /* CYGONCE_HAL_PLATFORM_SETUP_H */
