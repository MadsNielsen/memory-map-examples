#ifndef CYGONCE_HAL_ARM_XSCALE_VIPER_PLF_IO_H
#define CYGONCE_HAL_ARM_XSCALE_VIPER_PLF_IO_H
//==========================================================================
//
//      plf_io.h
//
//      Platform specific support (register layout, etc)
//
//==========================================================================
//####ECOSGPLCOPYRIGHTBEGIN####
// -------------------------------------------
// This file is part of eCos, the Embedded Configurable Operating System.
// Copyright (C) 1998, 1999, 2000, 2001, 2002 Red Hat, Inc.
//
// eCos is free software; you can redistribute it and/or modify it under
// the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 or (at your option) any later version.
//
// eCos is distributed in the hope that it will be useful, but WITHOUT ANY
// WARRANTY; without even the implied warranty of MERCHANTABILITY or
// FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
// for more details.
//
// You should have received a copy of the GNU General Public License along
// with eCos; if not, write to the Free Software Foundation, Inc.,
// 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA.
//
// As a special exception, if other files instantiate templates or use macros
// or inline functions from this file, or you compile this file and link it
// with other works to produce a work based on this file, this file does not
// by itself cause the resulting work to be covered by the GNU General Public
// License. However the source code for this file must still be made available
// in accordance with section (3) of the GNU General Public License.
//
// This exception does not invalidate any other reasons why a work based on
// this file might be covered by the GNU General Public License.
//
// Alternative licenses for eCos may be arranged by contacting Red Hat, Inc.
// at http://sources.redhat.com/ecos/ecos-license/
// -------------------------------------------
//####ECOSGPLCOPYRIGHTEND####
//==========================================================================
//#####DESCRIPTIONBEGIN####
//
// Author(s):    <icampbell@arcom.com>
// Date:         2003-01-27
//
//####DESCRIPTIONEND####
//
//==========================================================================

#include <pkgconf/hal.h>
#include <cyg/hal/hal_io.h>             // IO macros
#include <cyg/hal/viper.h>

#define CYGHWR_REDBOOT_LINUX_ATAG_MEM(_p_)                                                      \
    CYG_MACRO_START                                                                             \
    CYG_ADDRWORD ram_size = hal_dram_size;                                                      \
    /* Next ATAG_MEM. */                                                                        \
    _p_->hdr.size = (sizeof(struct tag_mem32) + sizeof(struct tag_header))/sizeof(long);        \
    _p_->hdr.tag = ATAG_MEM;                                                                    \
    /* Round up so there's only one bit set in the memory size.                                 \
     * Don't double it if it's already a power of two, though.                                  \
     */                                                                                         \
    _p_->u.mem.size  = 1<<hal_msbindex(ram_size);                                               \
    if (_p_->u.mem.size < ram_size)                                                             \
	    _p_->u.mem.size <<= 1;                                                              \
    _p_->u.mem.start = CYGARC_PHYSICAL_ADDRESS(CYGMEM_REGION_ram);                              \
    CYG_MACRO_END

// SDRAM is aliased as uncached memory for drivers.
#define CYGARC_UNCACHED_ADDRESS(_x_) \
  (((((unsigned long)(_x_)) >> 29)==0x0) ? (((unsigned long)(_x_))|0xc0000000) : (_x_))

static inline unsigned cygarc_physical_address(unsigned va)
{
    unsigned *ram_mmutab = (unsigned *)(VIPER_SDRAM_BASE | 0x4000);
    unsigned pte;

    pte = ram_mmutab[va >> 20];

    return (pte & 0xfff00000) | (va & 0xfffff);
}

// FIXME
#undef CYGARC_PHYSICAL_ADDRESS
#define CYGARC_PHYSICAL_ADDRESS(_x_) cygarc_physical_address(_x_)

static inline unsigned cygarc_virtual_address(unsigned pa)
{
    if (0xa0000000 <= pa && pa < 0xc0000000)
        return pa - 0xa0000000;
    return pa;
}

#define CYGARC_VIRTUAL_ADDRESS(_x_) cygarc_virtual_address(_x_)

// IDE/CF support
externC cyg_uint8 cyg_hal_plf_ide_read_uint8(int ctlr, cyg_uint32 reg);
externC void cyg_hal_plf_ide_write_uint8(int ctlr, cyg_uint32 reg, cyg_uint8 val);
externC cyg_uint16 cyg_hal_plf_ide_read_uint16(int ctlr, cyg_uint32 reg);
externC void cyg_hal_plf_ide_write_uint16(int ctlr, cyg_uint32 reg, cyg_uint16 val);
externC void cyg_hal_plf_ide_write_control(int ctlr, cyg_uint8 val);
externC cyg_bool cyg_hal_plf_ide_init(void);

#define HAL_IDE_NUM_CONTROLLERS 1

#define HAL_IDE_READ_UINT8( __ctlr, __reg, __val) \
    __val = cyg_hal_plf_ide_read_uint8((__ctlr),  (__reg))
#define HAL_IDE_READ_UINT16( __ctlr, __reg, __val) \
    __val = cyg_hal_plf_ide_read_uint16((__ctlr),  (__reg))

#define HAL_IDE_WRITE_UINT8( __ctlr, __reg, __val) \
    cyg_hal_plf_ide_write_uint8((__ctlr),  (__reg), (__val))
#define HAL_IDE_WRITE_UINT16( __ctlr, __reg, __val) \
    cyg_hal_plf_ide_write_uint16((__ctlr),  (__reg), (__val))
#define HAL_IDE_WRITE_CONTROL( __ctlr, __val) \
    cyg_hal_plf_ide_write_control((__ctlr),  (__val))

#define HAL_IDE_INIT() cyg_hal_plf_ide_init()

// I2C support
#if defined(CYGBLD_BUILD_VIPER_TPM) || defined(CYGBLD_BUILD_VIPER_AIM104_TPM)
#define HAL_I2C_EXPORTED_DEVICES				\
extern cyg_i2c_bus			hal_viper_tpm_bus;	\
extern cyg_i2c_device			cyg_i2c_tpm_atmel;
#endif

// Voltage scaling
extern void viper_set_vcore(unsigned long);
#define HAL_PLATFORM_VCORE(x) viper_set_vcore(x)

#endif //CYGONCE_HAL_ARM_XSCALE_VIPER_PLF_IO_H
