/**********************************************************************
 *
 * Filename:    blink.c
 * 
 * Description: eCos Blinking LED program.
 *
 * Notes:       
 *
 * Copyright (c) 2006 Anthony Massa and Michael Barr. All rights reserved.
 * This code is from the book Programming Embedded Systems, With C and
 * GNU Development Tools, 2nd Edition.
 * It is provided AS-IS, WITHOUT ANY WARRANTY either expressed or implied.
 * You may study, use, and modify it for any non-commercial purpose,
 * including teaching and use in open-source projects.
 * You may distribute it non-commercially as long as you retain this notice.
 * For a commercial use license, or to purchase the book,
 * please visit http://www.oreilly.com/catalog/embsys2.
 *
 **********************************************************************/

#include <cyg/kernel/kapi.h>
#include "stdint.h"
#include "pxa255.h"
#include "led.h"


#define TICKS_PER_SECOND	        (100)

#define LED_TASK_STACK_SIZE         (4096)
#define LED_TASK_PRIORITY           (12)


/* Declare the task variables. */
int8_t ledTaskStack[LED_TASK_STACK_SIZE];
cyg_thread ledTaskObj;
cyg_handle_t ledTaskHdl;


/**********************************************************************
 *
 * Function:    blinkLedTask
 *
 * Description: This task handles toggling the green LED at a
 *              constant interval.
 *
 * Notes:       
 *
 * Returns:     None.
 *
 **********************************************************************/ 
void blinkLedTask(cyg_addrword_t data)
{
    while (1)
    {
        /* Delay for 500 milliseconds. */
        cyg_thread_delay(TICKS_PER_SECOND / 2);

        ledToggle();
    }
}


/**********************************************************************
 *
 * Function:    cyg_user_start
 *
 * Description: Main routine for the eCos Blinking LED program. This
 *              function creates the LED task.
 * 
 * Notes:       This routine invokes the scheduler upon exit.
 *
 * Returns:     None.
 *
 **********************************************************************/
void cyg_user_start(void)
{
    /* Configure the green LED control pin. */
    ledInit();

    /* Create the LED task. */
    cyg_thread_create(LED_TASK_PRIORITY,
                      blinkLedTask,
                      (cyg_addrword_t)0,
                      "LED Task",
                      (void *)ledTaskStack,
                      LED_TASK_STACK_SIZE,
                      &ledTaskHdl,
                      &ledTaskObj);

    /* Notify the scheduler to start running the task. */
    cyg_thread_resume(ledTaskHdl);
}

