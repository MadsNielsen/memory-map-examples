/**********************************************************************
 *
 * Filename:    buzzer.c
 * 
 * Description: Buzzer device driver.
 *
 * Notes:       This file is specific to the Arcom board.
 * 
 * Copyright (c) 2006 Anthony Massa and Michael Barr. All rights reserved.
 * This code is from the book Programming Embedded Systems, With C and
 * GNU Development Tools, 2nd Edition.
 * It is provided AS-IS, WITHOUT ANY WARRANTY either expressed or implied.
 * You may study, use, and modify it for any non-commercial purpose,
 * including teaching and use in open-source projects.
 * You may distribute it non-commercially as long as you retain this notice.
 * For a commercial use license, or to purchase the book,
 * please visit http://www.oreilly.com/catalog/embsys2.
 *
 **********************************************************************/

#include "stdint.h"
#include "pxa255.h"
#include "viperlite.h"
#include "buzzer.h"


#define PIN23_FUNC_GENERAL          (0xFFFF3FFF)


/**********************************************************************
 *
 * Function:    buzzerInit
 *
 * Description: Initialize the GPIO pin that controls the buzzer.
 *
 * Notes:       This function is specific to the Arcom board.
 *
 * Returns:     None.
 *
 **********************************************************************/
void buzzerInit(void)
{
    /* Turn the GPIO pin voltage off. This should be done before the pins
     * are configured. */
    GPIO_0_CLEAR_REG = BUZZER;

    /* Make sure the buzzer control pin is set to perform general
     * purpose functions. RedBoot may have changed the pin's operation. */
    GPIO_0_FUNC_HI_REG &= PIN23_FUNC_GENERAL;

    /* Set the buzzer control pin to operate as output. */
    GPIO_0_DIRECTION_REG |= BUZZER;

    /* Turn the buzzer off. */
    GPIO_0_SET_REG = BUZZER;
}


/**********************************************************************
 *
 * Function:    buzzerToggle
 *
 * Description: Toggle the state of the buzzer.
 *
 * Notes:       This function is specific to the Arcom board.
 *
 * Returns:     None.
 *
 **********************************************************************/
void buzzerToggle(void)
{
    /* Check the current state of the buzzer control pin. Then change the
     * state accordingly. */
    if (GPIO_0_LEVEL_REG & BUZZER)
        GPIO_0_CLEAR_REG = BUZZER;
    else
        GPIO_0_SET_REG = BUZZER;
}

