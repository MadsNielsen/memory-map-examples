/**********************************************************************
 *
 * Filename:    moncont.c
 * 
 * Description: Monitor and Control program.
 *
 * Notes:       
 *
 * 
 * Copyright (c) 2006 Anthony Massa and Michael Barr. All rights reserved.
 * This code is from the book Programming Embedded Systems, With C and
 * GNU Development Tools, 2nd Edition.
 * It is provided AS-IS, WITHOUT ANY WARRANTY either expressed or implied.
 * You may study, use, and modify it for any non-commercial purpose,
 * including teaching and use in open-source projects.
 * You may distribute it non-commercially as long as you retain this notice.
 * For a commercial use license, or to purchase the book,
 * please visit http://www.oreilly.com/catalog/embsys2.
 *
 **********************************************************************/

#include "stdint.h"
#include "pxa255.h"
#include "viperlite.h"
#include "serial.h"
#include "buzzer.h"
#include "led.h"
#include "cli.h"


/**********************************************************************
 *
 * Function:    main
 *
 * Description: Monitor and control command line interface program.
 * 
 * Notes:       
 *
 * Returns:     This routine contains an infinite loop.
 *
 **********************************************************************/
int main(void)
{
    char rcvChar;
    int  bCommandReady = FALSE;

    /* Ensure the data and instruction caches are enabled. */
    DCACHE_ENABLE();
    ICACHE_ENABLE();

    /* Configure the green LED control pin. */
    ledInit();

    /* Configure the buzzer control pin. */
    buzzerInit();

    /* Configure the serial port. */
    serialInit();

    serialPutStr("Monitor and Control Program\r\n");
    serialPutChar('>');

    while (1)
    {
        /* Wait for a character. */
        rcvChar = serialGetChar();

        /* Echo the character back to the serial port. */
        serialPutChar(rcvChar);

        /* Build a new command. */
        bCommandReady = cliBuildCommand(rcvChar);

        /* Call the CLI command processing routine to verify the command entered 
         * and call the command function; then output a new prompt. */
        if (bCommandReady == TRUE)
        {
            bCommandReady = FALSE;
            cliProcessCommand();

            serialPutChar('>');
        }
    }

    return 0;
}
