/**********************************************************************
 *
 * Filename:    commands.c
 * 
 * Description: Command functions for command line interface.
 *
 * Notes:       
 *
 * 
 * Copyright (c) 2006 Anthony Massa and Michael Barr. All rights reserved.
 * This code is from the book Programming Embedded Systems, With C and
 * GNU Development Tools, 2nd Edition.
 * It is provided AS-IS, WITHOUT ANY WARRANTY either expressed or implied.
 * You may study, use, and modify it for any non-commercial purpose,
 * including teaching and use in open-source projects.
 * You may distribute it non-commercially as long as you retain this notice.
 * For a commercial use license, or to purchase the book,
 * please visit http://www.oreilly.com/catalog/embsys2.
 *
 **********************************************************************/

#include "stdint.h"
#include "viperlite.h"
#include "led.h"
#include "buzzer.h"
#include "serial.h"
#include "cli.h"
#include "commands.h"


/**********************************************************************
 *
 * Function:    commandsLed
 *
 * Description: Toggle the green LED command function.
 *
 * Notes:       
 *
 * Returns:     None.
 *
 **********************************************************************/
void commandsLed(void)
{
    ledToggle();
}


/**********************************************************************
 *
 * Function:    commandsBuzzer
 *
 * Description: Toggle the buzzer command function.
 *
 * Notes:       
 *
 * Returns:     None.
 *
 **********************************************************************/
void commandsBuzzer(void)
{
    buzzerToggle();
}


/**********************************************************************
 *
 * Function:    commandsHelp
 *
 * Description: Help command function.
 *
 * Notes:       
 *
 * Returns:     None.
 *
 **********************************************************************/
void commandsHelp(void)
{
    int idx;

    /* Loop through each command in the table and send out the command
     * name to the serial port. */
    for (idx = 0; gCommandTable[idx].name != NULL; idx++)
    {
        serialPutStr(gCommandTable[idx].name);
        serialPutStr("\r\n");
    }
}

