/**********************************************************************
 *
 * Filename:    cli.c
 * 
 * Description: Command line interface module.
 *
 * Notes:       
 *
 * 
 * Copyright (c) 2006 Anthony Massa and Michael Barr. All rights reserved.
 * This code is from the book Programming Embedded Systems, With C and
 * GNU Development Tools, 2nd Edition.
 * It is provided AS-IS, WITHOUT ANY WARRANTY either expressed or implied.
 * You may study, use, and modify it for any non-commercial purpose,
 * including teaching and use in open-source projects.
 * You may distribute it non-commercially as long as you retain this notice.
 * For a commercial use license, or to purchase the book,
 * please visit http://www.oreilly.com/catalog/embsys2.
 *
 **********************************************************************/

#include <string.h>
#include "stdint.h"
#include "viperlite.h"
#include "serial.h"
#include "commands.h"
#include "cli.h"


#define MAX_COMMAND_LEN             (10)
#define COMMAND_TABLE_SIZE          (4)

#define TO_UPPER(x)                 (((x >= 'a') && (x <= 'z')) ? ((x) - ('a' - 'A')) : (x))


command_t const gCommandTable[COMMAND_TABLE_SIZE] = 
{
    {"HELP",    commandsHelp,},
    {"LED",     commandsLed, },
    {"BUZZER",  commandsBuzzer, },
    {NULL,      NULL }
};

static char gCommandBuffer[MAX_COMMAND_LEN + 1];


/**********************************************************************
 *
 * Function:    cliBuildCommand
 *
 * Description: Put received characters into the command buffer. Once
 *              a complete command is received return TRUE.
 *
 * Notes:       
 *
 * Returns:     TRUE if a command is complete, otherwise FALSE.
 *
 **********************************************************************/
int cliBuildCommand(char nextChar)
{
    static uint8_t idx = 0;

    /* Don't store any new line characters or spaces. */
    if ((nextChar == '\n') || (nextChar == ' ') || (nextChar == '\t'))
        return FALSE;

    /* The completed command has been received. Replace the final carriage
     * return character with a NULL character to help with processing the
     * command. */
    if (nextChar == '\r')
    {
        gCommandBuffer[idx] = '\0';
        idx = 0;
        return TRUE;
    }

    /* Convert the incoming character to upper case. This matches the case
     * of commands in the command table. Then store the received character
     * in the command buffer. */
    gCommandBuffer[idx] = TO_UPPER(nextChar);
    idx++;

    /* If the command is too long, reset the index and process
     * the current command buffer. */
    if (idx > MAX_COMMAND_LEN)
    {
        idx = 0;
        return TRUE;
    }

    return FALSE;
}


/**********************************************************************
 *
 * Function:    cliProcessCommand
 *
 * Description: Look up the command in the command table. If the
 *              command is found, call the command's function. If the
 *              command is not found, output an error message.
 *
 * Notes:       
 *
 * Returns:     None.
 *
 **********************************************************************/
void cliProcessCommand(void)
{
    int bCommandFound = FALSE;
    int idx;

    /* Search for the command in the command table until it is found or
     * the end of the table is reached. If the command is found, break
     * out of the loop. */
    for (idx = 0; gCommandTable[idx].name != NULL; idx++)
    {
        if (strcmp(gCommandTable[idx].name, gCommandBuffer) == 0)
        {
            bCommandFound = TRUE;
		    break;
        }
    }

    /* If the command was found, call the command function. Otherwise,
     * output an error message. */
    if (bCommandFound == TRUE)
    {
        serialPutStr("\r\n");
        (*gCommandTable[idx].function)();
    }
    else
        serialPutStr("\r\nCommand not found.\r\n");
}

